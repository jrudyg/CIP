# VALUE MODEL — CANONICAL REFERENCE

This document defines how **[VALUE]** is calculated, interpreted, and enforced
when using structured configuration files (e.g. JSON) inside this project.

This file exists to ensure **human and AI agents share the same meaning of VALUE**
without re-explanation.

---

## Definition

**[VALUE] = (Benefit ÷ Risk) × Collaboration**

All decisions, outputs, and implementations should be evaluated against this model.

VALUE is **not subjective preference**.  
VALUE is a **governance calculation**.

---

## Dimensions

### 1. Benefit
Represents the **positive impact** of an action.

Examples:
- User clarity
- Reduced friction
- Increased reliability
- Faster iteration
- Improved maintainability

Scale (recommended): `0–10`

---

### 2. Risk
Represents **downside exposure**.

Includes:
- Technical fragility
- Scope creep
- Cognitive load
- Reversibility cost
- Governance violation

Scale (recommended): `0–10`  
Higher risk **reduces VALUE**.

---

### 3. Collaboration
Represents how well an action:
- Preserves trust
- Maintains shared understanding
- Enables future agents (human or AI)
- Avoids hidden complexity

Collaboration is a **multiplier**, not an additive score.

Scale (recommended): `0.0–2.0`

---

## Interpretation Rules

- High benefit with high risk does **not** guarantee high VALUE
- Low risk with low benefit may still be acceptable
- High collaboration can justify slower or more conservative approaches
- Actions that reduce collaboration are VALUE-negative even if “clever”

---

## JSON Usage Pattern (Reference)

Structured configuration files (e.g. `.json`) may include a VALUE block such as:

```json
{
  "value": {
    "benefit": 8,
    "risk": 3,
    "collaboration": 1.4,
    "rationale": "Improves clarity without structural change"
  }
}
```

This block is:
- Declarative
- Auditable
- Human-readable
- AI-enforceable

---

## Governance Rules

- VALUE is evaluated **before execution**
- If VALUE is unclear, agents must **[ALERT]**
- If VALUE is disputed, agents must **[ASK]**
- VALUE may be overridden **only** by USER authority

---

## Canonical Status

This document is:
- Canonical
- Stable
- Referenced by all agents
- Not subject to reinterpretation

Changes require explicit USER approval.

---

## Summary

VALUE is how this project:
- Chooses what to do
- Chooses what *not* to do
- Avoids false optimization
- Preserves creative and technical flow
