# CONTRACT VERSION COMPARISON SKILL - CONTINUATION FILE

**Created:** November 18, 2025  
**Purpose:** Resume skill development with Claude Code  
**Current Phase:** Phase 1 - File Creation  
**Next Phase:** Phase 2 - Comparison Scripts & Report Generation

---

## PROJECT OVERVIEW

### Objective
Create a Claude skill that compares two contract versions (.docx files) and generates professional Word comparison reports with:
- Executive summary with impact categorization
- 5-column detailed comparison table
- Visual redlines (RED deletions, GREEN additions)
- Business impact narratives in plain language
- Optional risk-framed recommendations

### Core Value Proposition
**Quality .docx generation** - Other prompts can analyze contracts; this skill delivers consistent, professional, reliable Word documents.

---

## PROJECT CONTEXT & STRATEGIC DECISIONS

### Business Context (Confidential - Never Mention Explicitly)
- Company squeezed between Owners and Subcontractors
- Leadership lacks confidence to push back
- Operating in perceived "owner's market" and "subcontractor's market"
- Recommendations must be evidence-based, tiered, reasonable (not aggressive)
- Risk-framed language fits cultural sensibilities

### Key Principle
**Legal subject matter - accuracy, relevancy, timeliness are non-negotiable**  
But practical implementation = strategic validation gates (not over-engineering)

---

## 15 DESIGN DECISIONS (ALL QUESTIONS ANSWERED)

### Q1: Section Numbering Mismatches
**Decision:** Content-based matching (clause title/content), NOT section numbers  
**Tie-breaker:** Latest version is definitive, denote with asterisk (*)

### Q2: Anonymization Token Matching
**Decision:** Show all cases, auto-handle if confidence â‰¥ 85%, flag for user review if < 85%

### Q3: Executive Summary Categories
**Decision:** Keep fixed categories for now (Critical/High/Important/Operational/Administrative)  
**Phase 2 Enhancement:** Custom categories

### Q4: Column Width Allocation
**Decision:** Priority order: 1) Readability, 2) Minimize pages, 3) Content space needs

### Q5: Visual Redline Validation
**Decision:** Mandatory validation before output, strategic QA gates (not over-engineering)  
**Focus:** Accuracy of changes captured, correct RED/GREEN formatting, no missed edits

### Q6: Business Impact Generation
**Decision:** Hybrid - AI generates for simple changes, flags complex ones for user input  
**Note:** 100% user QA is impractical

### Q7: Impact Classification Criteria
**Decision:** Hybrid (rules + AI) with priority order:
1. Limitation of Liability
2. Indemnification
3. IP Ownership
4. Compliance & Regulatory
5. Insurance
6. Operational
7. Financial
8. Payment terms* (*context-dependent: tied to SOW or flowdown)

### Q8: Accept/Negotiate Recommendations
**Decision:** Risk-framed tiers with Pattern Library guidance (internal, not cited)
- **CRITICAL ATTENTION** - Significant risk/exposure
- **RECOMMEND REVIEW** - Moderate concern
- **MONITOR** - Low risk, track only

**Note:** "MUST" too imperative for leadership culture; risk-framed language better fit

### Q9: Output Format
**Decision:** .docx only - rely on M365 features for conversion  
**Rationale:** Quality .docx generation IS the skill's core value

### Q10: Quality Validation Gates
**Decision:** Comprehensive validation (all checklist items)  
**Priority:** Accuracy > Quality > Consistency (processing time important but secondary)

### Q11: Template Iteration & Redesign
**Decision:** Deferred to Phase 2 - get base template working first

### Q12: Session Continuity
**Decision:** Auto-checkpoint at strategic points (save-as-you-go)  
**Checkpoints:** After extraction, after classification, after each user QA gate, before output

### Q13: Dual-Agreement Handling
**Decision:** ALWAYS alert user and ask for guidance based on contract type and contents detected

### Q14: Error Recovery
**Decision:** Fail fast + escalate with recovery options  
**No partial work on critical errors**

### Q15: Pattern Library Integration
**Decision:** Use patterns to inform recommendations, but DON'T explicitly cite them  
**Note:** Patterns based on AI recommendations (not final negotiated documents) - use as guidance framework

---

## SKILL ARCHITECTURE (CORRECT APPROACH)

### What Skills Actually Are
Skills are **instruction documents** for Claude, NOT software applications.

**Structure:**
```
contract-version-comparison/
â”œâ”€â”€ SKILL.md                          # Main instructions (~600 lines)
â”œâ”€â”€ scripts/                          # Standalone executable scripts
â”‚   â”œâ”€â”€ test_extraction.py
â”‚   â”œâ”€â”€ compare_documents.py         # Phase 2
â”‚   â””â”€â”€ generate_report.py           # Phase 2
â”œâ”€â”€ references/                       # Markdown docs Claude reads as needed
â”‚   â”œâ”€â”€ impact-classification.md     # âœ… Phase 1
â”‚   â”œâ”€â”€ report-format.md             # Phase 2
â”‚   â”œâ”€â”€ validation-checklist.md      # Phase 2
â”‚   â””â”€â”€ pattern-library-guide.md     # Phase 3
â””â”€â”€ assets/                           # Templates/files used in output
    â””â”€â”€ comparison-template.docx     # Phase 2
```

### Progressive Disclosure
1. **Metadata (name + description)** - Always in context (~100 words)
2. **SKILL.md body** - When skill triggers (<5k words)
3. **References** - As needed by Claude
4. **Scripts** - Executed without loading to context

---

## PHASE 1 STATUS

### What Should Exist Now
âœ… Directory structure created
âœ… SKILL.md (main instructions file)
âœ… references/impact-classification.md (detailed classification rules)
âœ… scripts/test_extraction.py (dependency validation)
âœ… README_PHASE1.md (documentation)

### Location
`/home/claude/contract-version-comparison/`

### What Was NOT Created (Issue Detected)
The files were NOT created in the previous session. Claude Code needs to execute Phase 1 file creation.

---

## PHASE 1 EXECUTION INSTRUCTIONS FOR CLAUDE CODE

### Step 1: Create Directory Structure
```bash
mkdir -p /home/claude/contract-version-comparison/{scripts,references,assets}
cd /home/claude/contract-version-comparison
```

### Step 2: Create SKILL.md
Create `/home/claude/contract-version-comparison/SKILL.md` with:

**Frontmatter:**
```yaml
---
name: contract-version-comparison
description: Generate professional .docx comparison reports for two contract versions with executive summary, 5-column analysis table, visual redlines (RED deletions, GREEN additions), and business impact narratives. Use when user uploads two .docx contract versions and requests comparison analysis for internal review, negotiation preparation, or client presentation.
---
```

**Body sections:**
1. Overview (core value proposition)
2. When to Use This Skill (triggers)
3. Workflow (8 phases):
   - Phase 1: Clarify Requirements (5 questions, one at a time)
   - Phase 2: Extract Documents (pandoc or python-docx)
   - Phase 3: Detect and Match Changes (content-based matching)
   - Phase 4: Classify Impact (using priority hierarchy)
   - Phase 5: Generate Recommendations (risk-framed tiers)
   - Phase 6: Build Document (5-column table + executive summary)
   - Phase 7: Validate Output (comprehensive checklist)
   - Phase 8: Deliver (to /mnt/user-data/outputs/)
4. Session Continuity (6 auto-checkpoints)
5. Quality Principles
6. References (list of reference files)

**Full SKILL.md content:** See Section "FULL FILE CONTENTS" below

### Step 3: Create references/impact-classification.md
Create `/home/claude/contract-version-comparison/references/impact-classification.md`

**Content sections:**
1. Priority Hierarchy
   - CRITICAL: 5 categories (Liability, Indemnification, IP, Compliance, Insurance)
   - HIGH PRIORITY: 2 categories (Operational, Financial)
   - IMPORTANT: 1 category (Payment terms - context-dependent)
   - OPERATIONAL: Administrative procedures
   - ADMINISTRATIVE: Non-substantive changes
2. Hybrid Classification Logic
3. Examples (4 detailed examples)

**Full impact-classification.md content:** See Section "FULL FILE CONTENTS" below

### Step 4: Create scripts/test_extraction.py
Create `/home/claude/contract-version-comparison/scripts/test_extraction.py`

**Purpose:** Test if pandoc and/or python-docx are available

**Functions:**
- test_pandoc_available()
- test_python_docx_available()
- test_extraction_pandoc(docx_file)
- test_extraction_python_docx(docx_file)

Make executable:
```bash
chmod +x /home/claude/contract-version-comparison/scripts/test_extraction.py
```

**Full test_extraction.py content:** See Section "FULL FILE CONTENTS" below

### Step 5: Create README_PHASE1.md
Create `/home/claude/contract-version-comparison/README_PHASE1.md`

**Content:**
- What Was Created
- Testing Phase 1
- What's Working
- What's NOT in Phase 1
- Ready for Phase 2
- Questions Before Phase 2

**Full README_PHASE1.md content:** See Section "FULL FILE CONTENTS" below

### Step 6: Validate Creation
```bash
# Verify structure
ls -R /home/claude/contract-version-comparison/

# Run dependency test
cd /home/claude/contract-version-comparison
python scripts/test_extraction.py
```

### Step 7: Report Results
Provide:
- âœ… Confirmation all files created
- ðŸ“Š Pandoc availability status
- ðŸ“Š python-docx availability status
- âš ï¸ Any issues encountered
- ðŸ“ Directory listing output

---

## FULL FILE CONTENTS

### File 1: SKILL.md (600 lines)

```markdown
---
name: contract-version-comparison
description: Generate professional .docx comparison reports for two contract versions with executive summary, 5-column analysis table, visual redlines (RED deletions, GREEN additions), and business impact narratives. Use when user uploads two .docx contract versions and requests comparison analysis for internal review, negotiation preparation, or client presentation.
---

# Contract Version Comparison

## Overview

This skill compares two contract versions and generates a professional Word document with:
- Executive summary categorizing changes by impact level
- 5-column detailed comparison table
- Visual redlines (RED strikethrough deletions, GREEN bold additions)
- Business impact narratives in plain language
- Optional risk-framed recommendations

**Core value proposition:** Consistent, quality .docx generation. Other prompts can analyze contracts; this skill delivers professional, reliable Word documents.

---

## When to Use This Skill

Use when user:
- Uploads two .docx files that are versions of the same contract
- Asks to compare contract versions
- Needs professional comparison report
- Requests redline analysis
- Wants to understand changes between versions

---

## Workflow

### Phase 1: Clarify Requirements

Ask user these questions **ONE AT A TIME** (wait for response before next):

1. **"What are the version identifiers?"**
   - Example: "V3 vs V4", "October 2025 vs November 2025", "Original vs Revised"

2. **"What's your role in this agreement?"**
   - Options: Buyer, Seller, Vendor, Customer, Systems Integrator, Channel Partner, Service Provider

3. **"What's the comparison purpose?"**
   - Options: Internal review, Negotiation preparation, Client presentation, Due diligence

4. **"Which sections should I analyze?"**
   - Options: All substantive changes, Specific sections only (user lists), Exclude certain sections

5. **"Do you want recommendations?"**
   - Options: Yes (include Accept/Negotiate/Monitor guidance), No (just document changes)

**Document type verification:**
Before proceeding, analyze both documents and alert user:
- "I see [Contract Type A] V[X] and [Contract Type B] V[Y]"
- "Confirm: comparing versions of same agreement?"
- Wait for explicit confirmation

**Checkpoint 1:** Save user context (role, purpose, scope, recommendations flag)

---

### Phase 2: Extract Documents

**Read the docx skill documentation first:**
```bash
cat /mnt/skills/public/docx/SKILL.md
```

**Extract both documents using pandoc:**
```bash
pandoc --track-changes=accept file1.docx -o v1_extracted.md
pandoc --track-changes=accept file2.docx -o v2_extracted.md
```

**Fallback if pandoc unavailable:**
Use python-docx for text extraction (see test script in scripts/ directory)

**Error handling:**
If extraction fails, stop immediately with clear error message and recovery options.

**Checkpoint 2:** Save extracted content

---

### Phase 3: Detect and Match Changes

**Content-based section matching:**
1. Match sections by clause title/content (NOT by section number)
2. Handle section numbering differences gracefully
3. Tie-breaker rule: Latest version is definitive
4. Mark tie-breaker cases with asterisk (*)

**Anonymization token handling:**
- Detect company name variations ([COMPANY_A], [CLIENT], actual names)
- Auto-handle if confidence â‰¥ 85% that tokens refer to same entity
- Flag for user review if confidence < 85%

**Change detection:**
For each matched section, identify substantive differences.
Ignore: company name substitutions, formatting, typos, grammar fixes

**Checkpoint 3:** Save detected changes with mappings

---

### Phase 4: Classify Impact and Generate Narratives

**Impact classification - Read references/impact-classification.md for detailed rules.**

**Priority order:**
1. Limitation of Liability â†’ CRITICAL
2. Indemnification â†’ CRITICAL
3. IP Ownership â†’ CRITICAL
4. Compliance & Regulatory â†’ CRITICAL
5. Insurance â†’ CRITICAL
6. Operational â†’ HIGH PRIORITY
7. Financial â†’ HIGH PRIORITY
8. Payment terms â†’ Context-dependent (check if tied to SOW or flowdown)

**Business impact generation:**
- Simple/clear changes: AI generates automatically
- Complex changes: Flag for user input
- Strategic QA gate: Present samples to user for approval

**Business impact writing guidelines:**
Focus on: financial, timeline, relationship, operational, risk, strategic effects
Use plain language, be concrete and specific, 2-4 sentences max

**Good example:**
> "Payment timing extends from 30 to 45 calendar days, creating a 15-day cash flow gap. For a $100K project, you'll need to finance ~$50K for an additional two weeks. This impacts quarterly cash flow projections."

**Bad example:**
> "Modified payment provisions may create operational inefficiencies under commercially reasonable standards."

**Checkpoint 4:** Save classified changes with narratives

---

### Phase 5: Generate Recommendations (if requested)

**Risk-framed recommendation framework:**

Three-tier structure:
- **CRITICAL ATTENTION** - Significant risk/exposure
- **RECOMMEND REVIEW** - Moderate concern
- **MONITOR** - Low risk, track only

Each recommendation includes:
1. Risk tier
2. Brief rationale (1-2 sentences)
3. Reasonable talking point

**Example format:**
```
Recommendation: RECOMMEND REVIEW

Rationale: 7-day cure period below industry standard (30 days).
Pattern shows 80% acceptance when positioned as operational necessity.

Talking point: "We need reasonable time to remedy issues, especially
during holidays or when key personnel unavailable."
```

**Note:** Use Pattern Library internally but do NOT cite explicitly in output.

**Checkpoint 5:** Save recommendations

---

### Phase 6: Build Document

**Read docx skill for document generation patterns.**

**Document structure:**

**Part 1: Executive Summary**
```
[Document Name] Version Comparison
Version [X] to Version [Y] Analysis
Comparison Date: [Date]

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

CHANGE SUMMARY

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Impact Category     â”‚ Count â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Critical Changes    â”‚   ##  â”‚
â”‚ High Priority       â”‚   ##  â”‚
â”‚ Important           â”‚   ##  â”‚
â”‚ Operational         â”‚   ##  â”‚
â”‚ Administrative      â”‚   ##  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ TOTAL SUBSTANTIVE   â”‚   ##  â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”˜

â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

EXECUTIVE OVERVIEW

[2-3 paragraph narrative of most significant changes]

Key themes:
â€¢ [Theme 1]
â€¢ [Theme 2]
â€¢ [Theme 3]
```

**Part 2: Detailed Comparison Table (5 columns)**

| # | Section / Recommendation | V[X] Clause Language | V[Y] Clause Language | Business Impact |
|:---:|:---|:---|:---|:---|
| 1 | **Section X.X**<br><br>**Recommendation:** [Tier]<br><br>**Rationale:** [Brief] | [Exact original] | [Text with redlines]<br><br>~~Deleted RED~~<br><br>**Added GREEN** | [2-4 sentence narrative] |

**Column width priority:**
1. Readability (most important)
2. Minimize pages
3. Content space needs

**Dynamic width allocation:**
- Column 1 (#): 5%
- Column 2 (Section/Rec): 20%
- Column 3 (V[X]): 25-30%
- Column 4 (V[Y]): 25-30%
- Column 5 (Impact): 20-25%

---

### Phase 7: Validate Output

**Comprehensive validation checklist:**
- [ ] All substantive changes captured
- [ ] Section references accurate
- [ ] Redline formatting correct (RED deletions, GREEN additions)
- [ ] Business impact narratives complete
- [ ] Recommendations present if requested
- [ ] Executive summary totals match table count
- [ ] Impact classifications follow rules
- [ ] No company name changes included (unless entity changed)

**If validation fails:** Stop and report issues with recovery options

**Checkpoint 6:** Final state before delivery

---

### Phase 8: Deliver

**Output file:**
```
Filename: [DocName]_V[X]_to_V[Y]_Comparison_[YYYYMMDD].docx
Location: /mnt/user-data/outputs/
Format: Microsoft Word (.docx)
```

Provide summary and download link to user.

---

## Session Continuity

**Auto-checkpoint at:**
1. After user confirmation (Phase 1)
2. After document extraction (Phase 2)
3. After change detection (Phase 3)
4. After impact analysis (Phase 4)
5. After recommendations (Phase 5)
6. Before final generation (Phase 6)

**Recovery on session break:** Load most recent checkpoint, verify context, resume.

---

## Quality Principles

**Legal subject matter - accuracy non-negotiable**
- Validate section references against source documents
- Verify all changes captured
- Check redline formatting precision
- Strategic validation gates (not over-engineering)

**Evidence-based recommendations**
- Use Pattern Library internally for guidance
- Risk-framed language (not imperative)
- Reasonable talking points

**Quality .docx generation is core value**
- Professional formatting
- Readable column widths
- Ready for distribution

---

## References

Load these files when needed:

- `references/impact-classification.md` - Detailed classification logic
- `references/report-format.md` - Complete output specifications (Phase 2)
- `references/validation-checklist.md` - Quality checks (Phase 2)
- `references/pattern-library-guide.md` - Internal pattern usage (Phase 2)

---

**END OF SKILL.md**
```

### File 2: references/impact-classification.md (300 lines)

```markdown
# Impact Classification Rules

## Priority Hierarchy

### CRITICAL (Highest Priority)

**1. Limitation of Liability**
- Liability caps (changes to amounts or removal)
- Carve-outs to liability limits
- Unlimited liability provisions
- Insurance requirements tied to liability

**Classification triggers:**
- Any change to "shall not exceed" language
- Addition/removal of liability carve-outs
- Changes to indemnification limits
- Modifications to consequential damages exclusions

---

**2. Indemnification**
- Indemnification scope (who indemnifies whom)
- Knowledge qualifiers ("to Company's knowledge")
- Defense obligations and cost allocation
- Third-party claim procedures

**Classification triggers:**
- Changes from mutual to one-way indemnification
- Addition/removal of knowledge qualifiers
- Modifications to indemnity scope
- Defense cost allocation changes

---

**3. IP Ownership**
- Work-for-hire provisions
- IP ownership transfers
- License grants and restrictions
- Background vs. foreground IP

**Classification triggers:**
- Changes to IP ownership (customer vs. vendor)
- License scope modifications
- IP warranty changes
- Background IP exclusions

---

**4. Compliance & Regulatory**
- Regulatory compliance requirements
- Audit rights and obligations
- Data protection and privacy
- Export control restrictions

**Classification triggers:**
- New compliance obligations
- Audit right additions/expansions
- Data protection requirement changes
- Industry-specific regulation additions

---

**5. Insurance**
- Insurance types required
- Coverage limits
- Additional insured requirements
- Proof of insurance timing

**Classification triggers:**
- Changes to required coverage limits
- Addition of insurance types
- Additional insured modifications
- Certificate of insurance timing

---

### HIGH PRIORITY

**6. Operational**
- Termination rights and cure periods
- Warranties and representations
- Acceptance criteria
- Service level agreements

**Classification triggers:**
- Changes to termination notice periods
- Cure period modifications
- Warranty scope changes
- SLA metric adjustments

---

**7. Financial**
- Fee structures and pricing
- Markup limitations
- Cost reimbursement terms
- Financial reporting requirements

**Classification triggers:**
- Pricing structure changes
- Markup cap additions/removals
- Reimbursable cost modifications
- Financial audit right changes

---

### IMPORTANT (Context-Dependent)

**8. Payment Terms**

**Requires context analysis:**

**Scenario A - Tied to SOW:**
If payment terms reference Statement of Work milestones:
- Classification: **IMPORTANT** or **HIGH PRIORITY**
- Rationale: Direct impact on cash flow timing

**Scenario B - Flowdown from Owner Contract:**
If payment terms must match upstream owner contract:
- Classification: **CRITICAL** or **HIGH PRIORITY**
- Rationale: Misalignment creates financing gap

**Scenario C - Standard Net 30/60:**
If payment terms are standard commercial terms:
- Classification: **IMPORTANT** or **OPERATIONAL**
- Rationale: Routine business terms

**Classification triggers:**
- Payment timing changes (Net 30 â†’ Net 45)
- Milestone payment structure modifications
- Advance payment percentage changes
- Disputed payment procedures

**Analysis checklist:**
- [ ] Is payment tied to SOW deliverables?
- [ ] Must payment match owner contract terms?
- [ ] Does change create financing burden?
- [ ] Is payment method modified (ACH, wire, check)?

---

### OPERATIONAL

**9. Administrative Procedures**
- Notice requirements and addresses
- Approval processes and response times
- Reporting and documentation
- Meeting and communication protocols

**Classification triggers:**
- Response time changes
- Approval authority modifications
- Reporting frequency changes
- Notice method updates

---

### ADMINISTRATIVE

**10. Non-Substantive Changes**
- Contact information updates
- Definition clarifications (no meaning change)
- Exhibit reference corrections
- Grammar and spelling fixes

**Classification triggers:**
- Company address changes
- Phone/email updates
- Exhibit renumbering
- Typographical corrections

---

## Hybrid Classification Logic

**Use rules for obvious cases:**
- Liability cap change â†’ CRITICAL (automatic)
- Indemnification scope â†’ CRITICAL (automatic)
- IP ownership transfer â†’ CRITICAL (automatic)

**Use AI judgment for ambiguous cases:**
- Is this warranty change CRITICAL or HIGH PRIORITY?
- Is this payment term IMPORTANT or OPERATIONAL?
- Does this operational change have CRITICAL implications?

**When uncertain:**
- Classify one level higher for safety
- Flag for user review in recommendations
- Explain reasoning in business impact narrative

---

## Examples

**Example 1: Clear CRITICAL**
```
Change: "Liability shall not exceed $1,000,000" â†’ "Liability is unlimited"
Classification: CRITICAL
Rationale: Removes all liability protection, creates unquantifiable exposure
```

**Example 2: Context-Dependent IMPORTANT**
```
Change: "Payment Net 30 days" â†’ "Payment Net 45 days"
Context: Downstream supplier requires Net 30 from you
Classification: HIGH PRIORITY (creates 15-day financing gap)
Rationale: You must pay supplier before customer pays you
```

**Example 3: Ambiguous â†’ AI Judgment**
```
Change: "30-day cure period" â†’ "7-day cure period"
AI Analysis:
- 7 days insufficient for operational remedy
- Creates termination risk
- User has weak leverage
Classification: HIGH PRIORITY (not CRITICAL, but significant)
Rationale: Operational risk elevated, but not dealbreaker
```

**Example 4: ADMINISTRATIVE**
```
Change: "Company address: 123 Old St" â†’ "Company address: 456 New St"
Classification: ADMINISTRATIVE
Rationale: Contact information update, no business impact
```

---

**END OF IMPACT CLASSIFICATION REFERENCE**
```

### File 3: scripts/test_extraction.py (150 lines)

```python
#!/usr/bin/env python3
"""
Test script to validate document extraction approach.
Tests both pandoc and python-docx methods.
"""

import sys
import subprocess
from pathlib import Path

def test_pandoc_available():
    """Check if pandoc is installed and accessible."""
    try:
        result = subprocess.run(['pandoc', '--version'],
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("âœ“ Pandoc available")
            print(f"  Version: {result.stdout.split()[1]}")
            return True
        else:
            print("âœ— Pandoc not available")
            return False
    except FileNotFoundError:
        print("âœ— Pandoc not found")
        return False

def test_python_docx_available():
    """Check if python-docx is installed."""
    try:
        import docx
        print("âœ“ python-docx available")
        return True
    except ImportError:
        print("âœ— python-docx not available")
        print("  Install with: pip install python-docx")
        return False

def test_extraction_pandoc(docx_file):
    """Test pandoc extraction on a sample file."""
    if not Path(docx_file).exists():
        print(f"âœ— Test file not found: {docx_file}")
        return False

    try:
        output_file = "test_extraction.md"
        result = subprocess.run([
            'pandoc',
            '--track-changes=accept',
            docx_file,
            '-o',
            output_file
        ], capture_output=True, text=True)

        if result.returncode == 0 and Path(output_file).exists():
            print(f"âœ“ Pandoc extraction successful: {output_file}")
            # Show first few lines
            with open(output_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()[:10]
                print("\nFirst 10 lines:")
                print("".join(lines))
            return True
        else:
            print(f"âœ— Pandoc extraction failed")
            if result.stderr:
                print(f"  Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"âœ— Pandoc extraction error: {e}")
        return False

def test_extraction_python_docx(docx_file):
    """Test python-docx extraction on a sample file."""
    if not Path(docx_file).exists():
        print(f"âœ— Test file not found: {docx_file}")
        return False

    try:
        from docx import Document

        doc = Document(docx_file)
        print(f"âœ“ python-docx extraction successful")
        print(f"  Paragraphs: {len(doc.paragraphs)}")
        print(f"  Tables: {len(doc.tables)}")

        # Show first few paragraphs
        print("\nFirst 5 paragraphs:")
        for i, para in enumerate(doc.paragraphs[:5]):
            if para.text.strip():
                print(f"{i+1}. {para.text[:100]}...")

        return True
    except Exception as e:
        print(f"âœ— python-docx extraction error: {e}")
        return False

def main():
    """Run all tests."""
    print("=" * 60)
    print("CONTRACT COMPARISON SKILL - EXTRACTION TEST")
    print("=" * 60)

    # Check dependencies
    print("\n1. Checking dependencies...")
    pandoc_ok = test_pandoc_available()
    python_docx_ok = test_python_docx_available()

    if not pandoc_ok and not python_docx_ok:
        print("\nâœ— FAILED: No extraction method available")
        print("\nInstall either pandoc or python-docx:")
        print("  - Pandoc: https://pandoc.org/installing.html")
        print("  - python-docx: pip install python-docx")
        return 1

    # Test with sample file if provided
    if len(sys.argv) > 1:
        test_file = sys.argv[1]
        print(f"\n2. Testing extraction on: {test_file}")

        if pandoc_ok:
            print("\n--- Testing Pandoc method ---")
            test_extraction_pandoc(test_file)

        if python_docx_ok:
            print("\n--- Testing python-docx method ---")
            test_extraction_python_docx(test_file)
    else:
        print("\nâœ“ Dependencies check complete")
        print("\nUsage: python test_extraction.py <sample.docx>")

    print("\n" + "=" * 60)
    print("Phase 1 dependency check complete")
    print("=" * 60)

    return 0

if __name__ == "__main__":
    sys.exit(main())
```

### File 4: README_PHASE1.md (Documentation)

```markdown
# Phase 1 Complete - Contract Version Comparison Skill

## What Was Created

### Core Files
- `SKILL.md` - Main skill instructions (~600 lines)
- `references/impact-classification.md` - Detailed classification rules (~300 lines)
- `scripts/test_extraction.py` - Validation script for dependencies (~150 lines)
- `README_PHASE1.md` - This file (documentation only, not part of skill)

### Directory Structure
```
contract-version-comparison/
â”œâ”€â”€ SKILL.md
â”œâ”€â”€ scripts/
â”‚   â””â”€â”€ test_extraction.py
â”œâ”€â”€ references/
â”‚   â””â”€â”€ impact-classification.md
â”œâ”€â”€ assets/
â”‚   (empty - Phase 2)
â””â”€â”€ README_PHASE1.md
```

## Testing Phase 1

### Test 1: Validate Structure
```bash
cd /home/claude/contract-version-comparison
ls -R
```

Expected: All directories and files present

### Test 2: Validate Dependencies
```bash
python scripts/test_extraction.py
```

Expected output:
```
âœ“ Pandoc available (or âœ— if not installed)
âœ“ python-docx available (or âœ— if not installed)
```

### Test 3: Test Extraction (if you have a sample .docx)
```bash
python scripts/test_extraction.py /path/to/sample.docx
```

Expected: Successful extraction via available method

## What's Working in Phase 1

âœ… Proper Claude skill structure
âœ… SKILL.md has correct YAML frontmatter for triggering
âœ… Progressive disclosure (SKILL.md â†’ references)
âœ… Impact classification rules documented
âœ… Extraction method testable
âœ… Follows "concise is key" principle

## What's NOT in Phase 1 (Coming in Phase 2-3)

âŒ Actual comparison logic script
âŒ Report generation script
âŒ Word document template
âŒ Additional reference files (report-format.md, validation-checklist.md, etc.)
âŒ Packaged .skill file

## Ready for Phase 2

Phase 2 will add:
- `scripts/compare_documents.py` - Comparison detection logic
- `scripts/generate_report.py` - Word document generation
- `assets/comparison-template.docx` - Base template
- `references/report-format.md` - Output specifications
- Complete workflow testing

## Questions to Answer Before Phase 2

1. Did all files create successfully?
2. Does test_extraction.py run without errors?
3. Is pandoc available or should we use python-docx?
4. Do you have sample contract files to test with?
5. Any adjustments needed to SKILL.md workflow before proceeding?
```

---

## NEXT STEPS FOR CLAUDE CODE

### Immediate Actions Required

1. **Execute Phase 1 file creation** (all 4 files above)
2. **Run validation test:** `python scripts/test_extraction.py`
3. **Report results:**
   - File creation status
   - Dependency availability (pandoc/python-docx)
   - Any errors encountered
   - Directory structure confirmation

### After Phase 1 Complete

**Phase 2 will add:**
- Comparison detection script
- Report generation script
- Word template file
- Additional reference documentation
- End-to-end workflow testing

**Phase 3 will add:**
- Pattern Library integration guide
- Complete validation framework
- Additional reference files
- User documentation

**Phase 4 will:**
- Package skill as .skill file
- Final testing and validation
- Deployment preparation

---

## CRITICAL REMINDERS

1. **Ask questions one at a time** - Wait for user response before next question
2. **Legal subject matter** - Accuracy, relevancy, timeliness non-negotiable
3. **Quality .docx generation** - This is THE core value proposition
4. **Risk-framed language** - Fits leadership culture (not imperative "MUST")
5. **Strategic validation gates** - Not over-engineering, but comprehensive
6. **Pattern Library internal use only** - Don't cite explicitly in output

---

## CONTACT & HANDOFF

**Created by:** Contract Review System v1.2 Project  
**For:** Claude Code execution  
**Status:** Ready for Phase 1 file creation  
**Next Review:** After Phase 1 validation complete

---

**END OF CONTINUATION FILE**
