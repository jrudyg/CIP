# QUICK SETUP GUIDE - 5 MINUTES

## Step 1: Create Claude Project (1 minute)

1. Go to claude.ai
2. Click "Projects" → "Create Project"
3. Name: "Contract Review System"

## Step 2: Upload Core Files (2 minutes)

Upload these 5 files to project knowledge:

✅ `00_PROJECT_INSTRUCTIONS_v1_1_EPC_OPTIMIZED.docx`
✅ `01_CONTRACT_REVIEW_SYSTEM_v1_2.md`
✅ `02_PATTERN_LIBRARY_v1_2_CORE.md`
✅ `03_QUICK_REFERENCE_CHECKLIST_v1_2.md`
✅ `CONTRACT_REVIEW_SYSTEM_RAG_REFERENCE.md`

## Step 3: Install Skill (1 minute)

1. Upload entire `contract-version-comparison/` folder as a skill
2. Skill auto-activates when you upload 2 contract versions

## Step 4: Set Custom Instructions (Optional, 1 minute)

Add to project custom instructions:
```
Ask me questions one at a time, waiting for my response.
Always audit logic before presenting.
Ask before updating artifacts.
Use silent mode by default.
```

## Step 5: Test It (Immediate)

Upload any .docx contract and watch it activate!

You should see:
1. "What's your position in this contract?"
2. "What's your negotiation leverage?"
3. "Brief narrative about the situation?"

Then it starts reviewing clause-by-clause.

---

## Two Operating Modes

**STANDARD MODE** - Clause-by-clause review
- Upload 1 contract → Activates automatically
- Reviews in original order
- One clause at a time
- Waits for your approval

**COMPARISON MODE** - Version comparison
- Upload 2 versions → Activates automatically
- Detects all changes
- Generates professional Word report
- QA/QC validation workflow

---

## Troubleshooting

**"Claude isn't following the process"**
→ Verify files uploaded to project knowledge (not just uploaded to chat)

**"Comparison mode not working"**
→ Ensure skill folder uploaded correctly
→ Upload both .docx files at same time

**"Getting errors"**
→ Use .docx format only (not .doc or PDF)
→ Check files aren't password protected

---

## Need Help?

Read the main README.md for complete documentation.

**You're ready to go!**
