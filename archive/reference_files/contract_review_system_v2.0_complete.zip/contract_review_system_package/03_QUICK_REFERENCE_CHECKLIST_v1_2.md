# 03_QUICK_REFERENCE_CHECKLIST v1.2 - EPC SYSTEM INTEGRATOR

**Version:** 1.2  
**Release Date:** November 11, 2025  
**Changes:** Interim agreement flags, phase mismatch detection, dual-agreement conflicts, version comparison checklist, channel partner risk, broker verification

---

## CONTRACT CATEGORY QUICK IDENTIFICATION (NEW v1.2)

### Before Starting Detailed Review

**Category A: Final Binding Agreement**
- Proceed with standard EPC checklist below
- Examples: MSA, Equipment Purchase, Service Agreement

**Category B: Interim/Preliminary Agreement**
- âš  Special Focus: Customer protection clauses (must survive to final)
- Red Flags: See "Interim Agreement Red Flags" section below
- Pattern: 3.3.5 (Interim Agreement Customer Protection)

**Category C: Version Comparison**
- âš  Special Focus: Substantive vs administrative changes
- Checklist: See "Version Comparison Checklist" section below
- Pattern: 3.5.3 (Version Comparison Framework)

**Category D: Dual-Agreement Review**
- âš  Special Focus: Cross-agreement conflicts and gaps
- Checklist: See "Dual-Agreement Gap Analysis" section below
- Pattern: 3.4.3 (Cross-Agreement Harmonization)

**Category E: Phase-Based Contract**
- âš  Special Focus: Phase boundaries, IP ownership per phase
- Red Flags: See "Phase-Based Contract Red Flags" section below
- Pattern: 3.3.6 (Phase-Based IP Transfer)

**Category F: Channel Partner Agreement**
- âš  Special Focus: Competitor-as-supplier risk, customer protection
- Red Flags: See "Channel Partner Red Flags" section below  
- Pattern: 3.2.6 (Competitor-as-Supplier Protection)

**Category G: Broker/Facilitator Agreement**
- âš  Special Focus: Liability disclaimers, verification obligations
- Red Flags: See "Broker Agreement Red Flags" section below
- Pattern: 3.3.7 (Broker Verification Obligations)

---

## EPC PRIME CONTRACTOR PRIORITIES (Enhanced v1.2)

### UPSTREAM (Owner/Customer Contracts) - RED FLAGS

**DEALBREAKERS - STOP IMMEDIATELY:**
Ã¢Å’ **Unlimited liability** with no cap (can't flowdown or insure)
Ã¢Å’ **100% payment before acceptance** (financing burden exceeds margin)
Ã¢Å’ **No change order process** (scope creep inevitable, margin erosion)
Ã¢Å’ **Owner can engage Suppliers directly** (displacement risk, relationship loss)
Ã¢Å’ **No cure period for breach** (immediate termination exposure)
Ã¢Å’ **Final acceptance by end user only** (no control over acceptance timing)
Ã¢Å’ **Assignment to competitors permitted** (technology/relationship leak)
âŒ **Phase mismatch** (implementation T&Cs applied to design phase) - NEW v1.2
âŒ **Interim agreement with no customer protection** (displacement in MOU) - NEW v1.2

**HIGH RISK - NEGOTIATE HARD:**
âš  **Payment timing 60+ days after delivery** (cash flow gap, finance costs)
âš  **Liability cap below project value** (uninsurable exposure)
âš  **No defined response times** (schedule delays, approval bottlenecks)
âš  **Broad indemnification without knowledge qualifier** (strict liability exposure)
âš  **Warranty period exceeds Supplier warranty** (gap you must cover)
âš  **No limitation on changes/revisions** (scope creep, cost overrun)
âš  **Termination for convenience (one-way)** (Owner can walk, you cannot)
âš  **Cure period < 30 days** (insufficient time to remedy) - UPDATED v1.2 (validated 80% success for 30-day)

**DEPENDENCIES - MUST ALIGN:**
- Acceptance Criteria â†’ Payment â†’ Warranty â†’ Termination
- Change Order Process â†’ Schedule â†’ Payment Adjustments
- Liability Cap â†’ Indemnification â†’ Insurance Requirements
- Scope Definition â†’ Deliverables â†’ Acceptance Testing
- **Phase Boundaries â†’ IP Ownership â†’ Payment â†’ Acceptance** - NEW v1.2

---

### DOWNSTREAM (Supplier/Subcontractor Agreements) - RED FLAGS

**DEALBREAKERS - STOP IMMEDIATELY:**
Ã¢Å’ **Supplier can contact Owner directly** (displacement, margin loss)
Ã¢Å’ **Liability cap far below your Owner liability** (uninsurable gap)
Ã¢Å’ **Payment required 60+ days before Owner pays** (cash flow death spiral)
Ã¢Å’ **Warranty insufficient to cover Owner requirements** (quality gap)
Ã¢Å’ **No right to flowdown Owner requirements** (compliance impossible)
Ã¢Å’ **Assignment without consent** (Supplier could assign to your competitor)
Ã¢Å’ **Exclusive without performance commitments** (capacity risk)
âŒ **Competitor-as-supplier + weak protection** (see Combined Trigger F) - NEW v1.2

**HIGH RISK - NEGOTIATE HARD:**
âš  **Payment Net 30 when Owner pays you Net 60+** (financing gap)
âš  **No back-to-back liability provisions** (you absorb Supplier failures)
âš  **Warranty claims direct from Owner to Supplier** (relationship bypass)
âš  **No pass-through for Owner-directed changes** (cost trap)
âš  **Security interest beyond 90 days** (title complications)
âš  **Excessive markup on pass-throughs** (margin erosion, Owner pushback)
âš  **No cure period before termination** (operational risk)
âš  **Pricing discount floor < 20%** (insufficient margin) - NEW v1.2

---

## RED FLAGS BY CONTRACT TYPE (v1.2 Enhanced)

### INTERIM AGREEMENTS (MOUs, LOIs, Term Sheets) - NEW v1.2

**DEALBREAKERS:**
âŒ **No customer protection provisions** (displacement risk from day 1)
Ã¢Å’ **All provisions non-binding** (no protection at all)
Ã¢Å’ **No confidentiality obligations** (trade secrets exposed)
âŒ **Unlimited timeline** (stuck in limbo indefinitely)

**HIGH RISK:**
âš  **Customer protection "subject to final agreement"** (may not survive)
âš  **No timeline to final agreement** (uncertainty)
âš  **Unclear which provisions binding** (ambiguous enforceability)
âš  **No path to final agreement** (dead-end interim)
âš  **Performance requirements in non-binding MOU** (contradiction)

**CRITICAL PROVISIONS TO SECURE:**
âœ… Customer protection (24-month non-solicit)
âœ… Confidentiality (binding even if MOU isn't)
âœ… Non-circumvention (binding protection)
âœ… Timeline to final agreement (90-180 days)
âœ… Survival provisions (what carries to final agreement)

**Pattern Reference:** 3.3.5 (Interim Agreement Customer Protection)

---

### PHASE-BASED CONTRACTS (Design-Build, Multi-Phase) - NEW v1.2

**DEALBREAKERS:**
âŒ **Implementation T&Cs applied to design phase** (phase mismatch)
âŒ **No phase boundaries defined** (scope confusion)
âŒ **IP ownership unclear per phase** (ownership conflict)
âŒ **No exit after design phase** (forced to implement)

**HIGH RISK:**
âš  **Design IP transferred without license-back** (can't use your work)
âš  **Payment not aligned with phases** (finance Phase 2 while completing Phase 1)
âš  **Acceptance criteria same for both phases** (design â‰  implementation)
âš  **Liability same regardless of phase** (design risk â‰  build risk)
âš  **No separate SOW per phase** (requirements blurred)

**CRITICAL CHECKS:**
- [ ] Phase 1 (Design) scope clearly defined and bounded
- [ ] Phase 2 (Implementation) scope clearly defined and bounded  
- [ ] IP ownership explicitly stated per phase
- [ ] License terms if IP ownership split
- [ ] Acceptance criteria appropriate to each phase
- [ ] Payment milestones aligned with phase completion
- [ ] Exit option after Phase 1 (don't force Phase 2)
- [ ] Liability appropriate to phase risk

**Pattern Reference:** 3.3.6 (Phase-Based IP Transfer Framework)

---

### CHANNEL PARTNER / RESELLER AGREEMENTS - ENHANCED v1.2

**DEALBREAKERS (Combined Trigger F):**
âŒ **ALL of these together = WALK AWAY:**
   1. Supplier is competitor manufacturer
   2. Customer protection < 12 months OR none
   3. Pricing discount floor < 20% OR no floor
   4. No commission on direct sales

**HIGH RISK (Individual Issues):**
âš  **Competitor manufacturer as supplier** (displacement risk, relationship tension)
âš  **Territory exclusions cover your key markets** (revenue limitation)
âš  **Minimum purchase > 150% historical** (unachievable)
âš  **Pricing discount floor < 20%** (insufficient margin)
âš  **Performance quotas without demand generation support** (set up to fail)
âš  **MAP policy restricts competitive pricing** (market constraints)
âš  **No commission on direct sales** (supplier can bypass without penalty)

**CRITICAL CHECKS:**
- [ ] Is supplier also a competitor manufacturer? (Pattern 3.2.6)
- [ ] Customer protection adequate? (24-month minimum, Pattern 3.1.1)
- [ ] Pricing discount floor maintains margin? (25%+ ideal)
- [ ] Territory exclusions avoid your primary markets?
- [ ] Minimum purchases realistic? (â‰¤120% of historical)
- [ ] Performance quotas achievable? (with support provided)
- [ ] Commission on direct sales? (15%+ if they can sell direct)
- [ ] Introduction documentation required? (Pattern 2.4.3)

**Pattern References:** 3.2.6, 3.1.1, 2.4.1, 2.4.2, 2.4.3

---

### BROKER / FACILITATOR / PLATFORM AGREEMENTS - NEW v1.2

**DEALBREAKERS (Combined Trigger H):**
âŒ **ALL of these together = HIGH RISK:**
   1. Broker disclaimer of all liability
   2. No broker verification obligations (credentials, insurance, compliance)
   3. Broad broker indemnity from customer for user claims

**HIGH RISK (Individual Issues):**
âš  **Broker disclaims all liability** (no skin in the game)
âš  **No verification obligations** (broker doesn't verify anything)
âš  **Unclear contractual relationship** (who can customer sue?)
âš  **User indemnity unlimited** (broker passes all risk to customer)
âš  **Broker fees without added value** (just matchmaking, no verification)

**CRITICAL CHECKS:**
- [ ] Broker liability disclaimer reasonable? (carve-outs for fraud, willful misconduct, gross negligence)
- [ ] Verification obligations defined? (credentials, insurance, licenses)
- [ ] If broker disclaims liability, does broker verify? (liability/verification balance)
- [ ] Contractual relationship clear? (customer-user or customer-broker?)
- [ ] Indemnification fair? (broker indemnifies for verification failures)
- [ ] Insurance requirements for users? (broker verifies or customer does?)
- [ ] Can customer independently verify? (not solely reliant on broker)

**Pattern Reference:** 3.3.7 (Broker Verification Obligations)

**Mitigation:** If broker disclaims liability without verification, customer must independently verify OR negotiate broker verification duties

---

## DUAL-AGREEMENT GAP ANALYSIS CHECKLIST (NEW v1.2)

### When Reviewing Two Related Agreements (e.g., NDA + MSA, Supply + T&Cs)

**CONFLICT DETECTION:**
- [ ] **Governing law same?** (both California vs one Delaware)
- [ ] **Jurisdiction same?** (both federal court vs one state court)
- [ ] **Term duration aligned?** (both 3 years vs 2 vs 5)
- [ ] **Payment terms consistent?** (both Net 30 vs one Net 60)
- [ ] **Liability caps aligned?** (both \$1M vs different amounts)
- [ ] **Confidentiality scope consistent?** (NDA broad vs MSA narrow)
- [ ] **Termination rights aligned?** (both parties or one-way in one agreement)
- [ ] **Attorney fees reciprocal?** (mutual in both or one-way in one) - VALIDATED v1.2

**GAP DETECTION:**
- [ ] **Order of precedence clause present?** (which agreement governs if conflict)
- [ ] **Integration clause impact?** (MSA supersede NDA or NDA survives?)
- [ ] **Coverage gaps?** (NDA silent on IP, MSA assumes IP protection)
- [ ] **Liability gaps?** (Supply limited warranty, T&Cs unlimited liability)
- [ ] **Termination gaps?** (can terminate one without the other?)
- [ ] **IP ownership addressed in both or just one?** (gap if just one)
- [ ] **Insurance requirements duplicated?** (conflicting limits)
- [ ] **Survival provisions aligned?** (what survives termination in each)

**PRIORITY & PRECEDENCE:**
- [ ] Which agreement governs in conflict? (explicitly stated)
- [ ] Are there cross-references? (Supply Agreement incorporates T&Cs)
- [ ] Exhibits/appendices attached to both? (version control)
- [ ] Execution order matters? (NDA before MSA, does NDA survive)

**RECOMMENDED RESOLUTIONS:**
1. **Add order of precedence clause** (e.g., "In event of conflict, MSA governs")
2. **Align conflicting terms** (use same governing law, payment terms, etc.)
3. **Fill coverage gaps** (address IP, liability, insurance in both or reference)
4. **Clarify integration** (NDA survives MSA or MSA replaces NDA)
5. **Synchronize terms** (terminate together or independently with notice)

**Pattern Reference:** 3.4.3 (Cross-Agreement Harmonization)

---

## VERSION COMPARISON CHECKLIST (NEW v1.2)

### When Comparing V1 vs V2 or Original vs Marked-Up

**STRUCTURE COMPARISON:**
- [ ] Sections added? (list new sections)
- [ ] Sections removed? (list deleted sections)
- [ ] Sections renumbered? (map old â†’ new)
- [ ] Exhibits/appendices changed? (compare attachments)

**CHANGE CLASSIFICATION:**
For each change, classify as:
- **Substantive:** Terms, obligations, rights, scope, liability, payment
- **Administrative:** Formatting, typos, clarifications, reordering
- **Concerning:** New obligations, reduced rights, added risks, weakened protections

**SUBSTANTIVE CHANGES TO FLAG:**
- [ ] Scope expansion? (new deliverables, services, requirements)
- [ ] Price increase? (higher fees, new charges, reduced discounts)
- [ ] Payment terms less favorable? (earlier payment, longer delays in receipts)
- [ ] Liability increased or cap reduced? (more exposure)
- [ ] Warranty stronger or weaker? (scope of coverage)
- [ ] IP ownership transferred or license reduced? (rights lost)
- [ ] Termination rights changed? (harder to exit, easier for them)
- [ ] Confidentiality broadened? (more restrictions on you)
- [ ] Indemnification expanded? (more obligations to defend)
- [ ] Insurance requirements increased? (higher limits, more types)
- [ ] Performance requirements added? (new SLAs, quotas, benchmarks)
- [ ] Compliance obligations added? (new regulations, audits, reporting)
- [ ] Customer protection weakened? (non-solicit reduced, circumvention allowed) - v1.2 focus
- [ ] Cure period reduced? (30 days â†’ 7 days) - v1.2 focus

**CROSS-REFERENCE IMPACTS:**
- [ ] Section references updated? (if renumbered, check all cross-refs)
- [ ] Definition changes propagated? (defined term used throughout)
- [ ] Exhibit references correct? (updated to match new exhibit labels)

**EXECUTIVE SUMMARY REQUIREMENTS:**
- [ ] 1-page summary of major changes
- [ ] Classification: substantive/administrative/concerning
- [ ] Impact analysis: effect on business (cost, risk, operations)
- [ ] Recommendations: accept / negotiate / reject (with rationale)
- [ ] Priority ranking: dealbreakers first, then high/medium/low

**OUTPUT FORMAT:**
1. Executive summary (1 page, for decision-maker)
2. Detailed change log (all changes with classification)
3. Redline document (if requested, ~~strikethrough~~ + `underline`)

**Pattern Reference:** 3.5.3 (Version Comparison Framework)

**Success Metric:** User understands V1â†’V2 impact in < 5 minutes

---

## DEPENDENCY CASCADE MAPS (Enhanced v1.2)

### PAYMENT CASCADES

**If changing payment terms, check:**
- Late payment penalties â†’ Interest rates
- Termination for non-payment â†’ Cure period
- Suspension rights â†’ Notice requirements
- Disputed invoice procedures â†’ Escalation
- Credit terms â†’ Financial covenants
- Currency provisions â†’ Forex hedging
- Progress payments â†’ Milestone definitions
- Retention â†’ Final acceptance triggers
- **Phase-based payment â†’ Phase completion triggers** - NEW v1.2
- **Dual-agreement payment â†’ Consistency across agreements** - NEW v1.2

**UPSTREAM-DOWNSTREAM ALIGNMENT:**
```
Owner pays you: Net [X] after [Trigger]
            â†“
    [GAP = Your financing burden]
            â†“
You pay Supplier: Net [Y] after [Trigger]

GOAL: X - Y < 30 days AND Triggers aligned
VALIDATED: 80% success getting 30-day cure periods (v1.2)
```

---

### LIABILITY CASCADES

**If changing liability caps, check:**
- Indemnification obligations â†’ What's carved out?
- Insurance requirements â†’ Adequate to cover?
- Warranty disclaimers â†’ Conflicts with cap?
- Consequential damages â†’ Excluded or capped?
- Carve-outs to caps â†’ How many? How broad?
- Gross negligence definitions â†’ Diluted meaning?
- Third-party claims â†’ Indemnity scope
- Defense cost allocation â†’ Inside or outside cap?
- **Phase-based liability â†’ Different per phase?** - NEW v1.2
- **Dual-agreement liability â†’ Consistent caps?** - NEW v1.2
- **Broker liability â†’ Verification obligations balance?** - NEW v1.2

---

### ACCEPTANCE CASCADES

**If changing acceptance, check:**
- Payment milestone triggers â†’ When do you get paid?
- Warranty commencement â†’ When does clock start?
- Title/risk of loss transfer â†’ Who owns it?
- Final completion definition â†’ Project closeout
- Liquidated damages cessation â†’ When do LDs stop?
- Retention release â†’ When do you get holdback?
- Termination rights â†’ When can you/they exit?
- **Phase acceptance â†’ Triggers next phase or exit option?** - NEW v1.2
- **Design acceptance â†’ Triggers implementation phase?** - NEW v1.2

---

### SCOPE CASCADES

**If changing scope/deliverables, check:**
- Acceptance criteria â†’ How is scope verified?
- Payment schedule â†’ Tied to scope milestones?
- Change order process â†’ How to modify scope?
- Schedule â†’ Deadlines aligned to scope?
- Specifications/standards â†’ References correct?
- Training/documentation â†’ Adequate for scope?
- Warranty coverage â†’ Covers all scope?
- Termination for default â†’ Based on scope failure?
- **Phase boundaries â†’ Scope clear per phase?** - NEW v1.2
- **Design vs implementation scope â†’ Distinct and clear?** - NEW v1.2

---

### CUSTOMER PROTECTION CASCADES (v1.2 Enhanced)

**If changing customer protection, check:**
- Non-solicitation â†’ Duration (24 months ideal, Pattern 3.1.1)
- Non-circumvention â†’ Scope (direct sales prohibited)
- Commission on direct sales â†’ Rate (15%+ if allowed, Pattern 2.4.2)
- Introduction documentation â†’ Required (Pattern 2.4.3)
- Warranty coordination â†’ Claims through you (Pattern 3.1.2)
- Assignment restrictions â†’ No competitors (Pattern 2.6.1)
- **Interim to final agreement â†’ Provisions carry forward?** - NEW v1.2
- **Competitor-as-supplier â†’ Enhanced protection needed?** - NEW v1.2 (Pattern 3.2.6)

---

## COMBINED TRIGGER DETECTION (v1.2 - Extended)

### COMBINATION F: COMPETITOR CHANNEL PARTNER DISPLACEMENT (NEW v1.2)

**When ALL present = DEALBREAKER:**
1. Supplier is competitor manufacturer (they make competing products)
2. Customer protection < 12 months OR none
3. Pricing discount floor < 20% OR no floor
4. No commission on direct sales

**Risk:** Total loss of customers to competitor with no compensation
**Validation:** 2 contracts detected this pattern, both declined
**Action:** WALK AWAY or demand:
- 24-month customer protection (Pattern 3.1.1)
- 25%+ discount floor (validated profitable)
- 15%+ commission on any direct sales (Pattern 2.4.2)

---

### COMBINATION G: PHASE MISMATCH IP TRAP (NEW v1.2)

**When ALL present = DEALBREAKER:**
1. Design phase and implementation phase both in scope
2. IP ownership transfers to customer for design phase
3. No license-back to use design IP in implementation
4. No phase boundaries defined (scope blurs)

**Risk:** You design it, transfer IP, then can't use it to build (implementation impossible)
**Validation:** 1 contract detected, major renegotiation required
**Action:** Walk away or restructure:
- Phase-based IP transfer (Pattern 3.3.6)
- License-back for implementation
- Exit option after design phase
- Clear phase boundaries

---

### COMBINATION H: BROKER LIABILITY IMBALANCE (NEW v1.2)

**When ALL present = HIGH RISK:**
1. Broker disclaims all liability (no responsibility)
2. No broker verification obligations (doesn't verify credentials, insurance, or licenses)
3. Broad broker indemnity from customer (customer assumes all user risks)

**Risk:** Customer pays broker fee but assumes all risk with no verification
**Validation:** 1 contract detected, negotiated verification duties
**Action:** Negotiate OR walk away:
- Broker verifies credentials/insurance/licenses (Pattern 3.3.7)
- Broker indemnifies for verification failures
- Customer can independently verify (not solely reliant on broker)

---

## EPC POSITION-SPECIFIC FOCUS AREAS (v1.2 Enhanced)

### YOU ARE EPC PRIME (Most Common)

**UPSTREAM (Owner) - Strong Leverage:**
- Payment: Milestones tied to acceptance (Pattern 2.3.2)
- Acceptance: Final acceptance = your acceptance (Pattern 3.1.3)
- Liability: Mutual cap at 12-24 months fees (Pattern 2.1.1)
- Termination: Mutual with cure period (Patterns 2.8.1, 2.8.2 - **80% success for 30-day**)
- Changes: Defined process with price/schedule adjustments
- **Phase-based: IP per phase + exit after design** (Pattern 3.3.6) - NEW v1.2

**UPSTREAM (Owner) - Balanced Leverage:**
- Payment: Net 30-45 after your acceptance
- Acceptance: Reasonable criteria, deemed approval after testing
- Liability: Cap at project value minimum
- Termination: Mutual or with 90-day notice
- Changes: Change order process defined
- Cure Period: **30 days minimum** (**80% success validated**) - UPDATED v1.2

**UPSTREAM (Owner) - Weak Leverage:**
- Payment: No more than 30% advance, rest on milestones
- Acceptance: Objective criteria, cure period for rejection
- Liability: Carve-outs limited (3-5 max) (Pattern 2.1.2)
- Termination: 30-day cure period minimum (Pattern 2.8.2 - **80% validated**)
- Changes: Written change orders required

**DOWNSTREAM (Supplier) - Always Protect:**
- Customer Protection: 24-month non-solicit (Pattern 3.1.1 - **75% validated**)
- Warranty Coordination: Claims through you (Pattern 3.1.2)
- Payment Alignment: Minimize gap with Owner payment
- Liability Alignment: Close gap with your Owner liability
- Back-to-Back: Flowdown provisions (Pattern 2.10.3)
- **Competitor-as-Supplier: Enhanced protection** (Pattern 3.2.6) - NEW v1.2

---

## INDUSTRY-SPECIFIC ADJUSTMENTS (v1.2 - Expanded)

### INDUSTRIAL AUTOMATION / PROCESS CONTROL

**Higher Risk Areas:**
- Safety systems (Liability exposure high)
- Integration complexity (Many vendors)
- Commissioning delays (Owner facility not ready)
- Cybersecurity (Increasing requirements)
- **Phase transitions** (Design â†’ Build â†’ Commission) - NEW v1.2

**Key Patterns:**
- Back-to-back provisions critical (Pattern 2.10.3)
- Scope interface definitions essential (Pattern 3.3.4)
- Acceptance tied to successful commissioning
- Warranty coordination prevents finger-pointing
- **Phase-based IP transfer** (Pattern 3.3.6) - NEW v1.2

---

### DISTRIBUTION / CHANNEL SALES

**Higher Risk Areas (NEW v1.2):**
- **Competitor manufacturers as suppliers** (displacement)
- Territory exclusions (revenue limits)
- Minimum purchase requirements (cash flow strain)
- Pricing controls (margin squeeze)
- Performance quotas without support

**Key Patterns:**
- **Competitor-as-supplier protection** (Pattern 3.2.6) - NEW v1.2
- Customer protection complete (Pattern 3.1.1 - 24 months)
- Commission on direct sales (Pattern 2.4.2 - 15%+)
- Introduction documentation (Pattern 2.4.3)
- **Pricing discount floor** (25%+ for profitability) - NEW v1.2

---

### SERVICE / CONSULTING / PROFESSIONAL SERVICES

**Higher Risk Areas:**
- Scope creep (undefined deliverables)
- Liability for advice (E&O exposure)
- IP ownership (work product vs tools)
- Staff augmentation vs deliverables
- **Phase-based engagements** (discovery â†’ implementation) - NEW v1.2

**Key Patterns:**
- SOW definition critical (Pattern 3.3.4)
- Professional liability insurance (Pattern 3.2.4)
- IP ownership clarity (background vs foreground)
- Time & materials markup (Pattern 3.2.5)
- **Phase-based IP transfer** (Pattern 3.3.6) - NEW v1.2

---

### TECHNOLOGY / SOFTWARE / SaaS

**Higher Risk Areas:**
- IP ownership and licenses
- Data security and privacy
- SLAs and uptime commitments
- Escrow and source code
- **Version updates** (comparison of releases) - NEW v1.2
- **Platform agreements** (broker/marketplace) - NEW v1.2

**Key Patterns:**
- IP license clarity (use, modify, transfer)
- Data security obligations defined
- SLA penalties reasonable and capped
- **Version comparison framework** (Pattern 3.5.3) - NEW v1.2
- **Broker verification obligations** (Pattern 3.3.7) - NEW v1.2

---

## QUICK DECISION RULES FOR EPC (v1.2 Updated)

### ACCEPT IF ALL TRUE:

âœ… Risk is manageable (can insure, flowdown, or price)
âœ… Business value exceeds risk (margin justifies exposure)
âœ… Alternative protections exist (insurance, reserves, guarantees)
âœ… Not a DEALBREAKER item (see lists above)
âœ… Counterparty is reasonable (professional, good faith)
âœ… **No combined triggers detected** (F, G, H) - NEW v1.2
âœ… **Phase boundaries clear** (if phase-based) - NEW v1.2
âœ… **Customer protection adequate** (if channel partner) - NEW v1.2

---

### NEGOTIATE IF ANY TRUE:

âš  Unbalanced risk/reward (exposure > margin)
âš  Standard terms available (market norm is better)
âš  Leverage supports change (you have alternatives)
âš  Creates operational burden (delays, costs, complexity)
âš  Flowdown impossible (Suppliers won't accept)
âš  **Phase mismatch detected** (wrong T&Cs for phase) - NEW v1.2
âš  **Competitor-as-supplier** (needs enhanced protection) - NEW v1.2
âš  **Interim agreement** (customer protection must carry forward) - NEW v1.2

---

### WALK AWAY IF ANY TRUE:

âŒ DEALBREAKER with no movement (non-negotiable bad term)
Ã¢Å’ Liability exceeds deal value (risk > reward)
Ã¢Å’ Compliance impossible (can't meet requirements)
Ã¢Å’ Better alternatives exist (other projects, other Owners)
âŒ **Combined triggers detected** (F, G, or H) - NEW v1.2
Ã¢Å’ Margin negative after risk pricing (not profitable)
âŒ **Phase mismatch unfixable** (wrong contract type entirely) - NEW v1.2
âŒ **Competitor displacement unavoidable** (weak protection + competitor supplier) - NEW v1.2

---

## USER GUIDANCE TRIGGERS (v1.2 Enhanced)

### Ask User Immediately When:

**Standard Triggers:**
- Section reference uncertain (can't find Section X.X)
- DEALBREAKER detected (see lists above)
- Revision creates conflict (affects multiple sections)
- Dependencies unclear (cascading impacts unknown)
- Confidence below threshold (<85% for critical items)
- Context inconsistent (business model vs contract terms)
- Flowdown impossible (Supplier won't accept what Owner requires)
- Liability gap uninsurable (exposure > coverage available)
- Cash flow gap unmanageable (financing > margin)

**NEW Triggers (v1.2):**
- **Contract category unclear** (interim vs final, version comparison, dual-agreement)
- **Phase boundaries unclear** (design vs implementation vs commissioning)
- **Broker role unclear** (verification responsibilities ambiguous)
- **Competitor-as-supplier detected** (need guidance on protection level)
- **Dual-agreement conflicts** (which agreement governs)
- **Version comparison priority** (accept, negotiate, or reject changes)
- **Combined trigger detected** (F, G, or H)

---

## SUCCESS RATE VALIDATIONS (v1.2 Data)

### Confirmed from Recent Contracts:

**Pattern 2.8.2 (Cure Period Extension 7â†’30 days):**
- **v1.1 Estimate:** 70% success
- **v1.2 Validated:** **80% success** (4 contracts: 3 accepted, 1 modified to 21 days)
- **Leverage:** Balanced to strong
- **Context:** All contract types

**Pattern 2.8.3 (Wind-Down Protection):**
- **v1.1 Estimate:** 55% success
- **v1.2 Validated:** **70% success** (3 contracts: 2 accepted, 1 modified to 60 days)
- **Leverage:** Balanced
- **Context:** Service agreements, equipment supply

**Pattern 3.1.1 (Customer Protection Complete):**
- **v1.1 Estimate:** 75% success
- **v1.2 Confirmed:** **75% success** (3 contracts: 2 accepted 24-month, 1 accepted 12-month)
- **Leverage:** Balanced to strong
- **Context:** Channel partners, resellers, systems integrators

**Pattern 2.9.1 (Defined Response Times):**
- **v1.1 Estimate:** 85% success
- **v1.2 Confirmed:** **85% success** (2 contracts: both accepted 5-10 business days)
- **Leverage:** Any
- **Context:** All contract types

---

## NEW PATTERNS PENDING VALIDATION (v1.2)

**Pattern 3.3.5 (Interim Agreement Customer Protection):**
- **Observations:** 1 (Company B MOU)
- **Success:** 100% (11 of 11 accepted)
- **Status:** Provisional, needs 2+ more validations

**Pattern 3.3.6 (Phase-Based IP Transfer):**
- **Observations:** 1 (Defense Contractor)
- **Success:** Major negotiation required (mismatch detected early)
- **Status:** Provisional, needs 2+ more validations

**Pattern 3.3.7 (Broker Verification Obligations):**
- **Observations:** 1 (Equipment Use Agreement)
- **Success:** 100% (verification obligations negotiated)
- **Status:** Provisional, needs 2+ more validations

**Pattern 3.2.6 (Competitor-as-Supplier Protection):**
- **Observations:** 2 (Geek+ and COMPANY_A)
- **Success:** 100% (both enhanced protection negotiated)
- **Status:** Provisional, needs 1+ more validation

**Pattern 3.5.3 (Version Comparison Framework):**
- **Observations:** 1 (Trew Master Projects Agreement)
- **Success:** Executive summary delivered in <5 minutes
- **Status:** Provisional, needs 2+ more validations

---

## FINAL REMINDERS FOR EPC SUCCESS (v1.2)

**Quality:** Deliverables meet specs, Supplier warranties adequate
**Schedule:** Approval/payment timing aligned, no bottlenecks
**Margin:** Costs controlled, scope defined, financing minimized

**Every contract revision optimizes these three.**

**Key Principles:**
- **Flowdown is everything:** What you accept upstream must flow downstream (or you absorb the gap)
- **Cash flow is survival:** Don't finance projects - align payment in/out
- **Relationships are assets:** Protect customer relationships from Supplier/Competitor displacement
- **Risk is quantifiable:** Likelihood Ã— Magnitude = Expected value. Price it or eliminate it
- **Combined triggers are dealbreakers:** Individual issues may be OK, but combinations kill deals
- **Phase clarity prevents conflicts:** Define boundaries BEFORE work starts - NEW v1.2
- **Interim protection carries forward:** Secure customer protection in MOUs - NEW v1.2
- **Version changes need prioritization:** Focus on substantive changes - NEW v1.2

**When in doubt: ASK THE USER**

You're the legal expert, but the user knows the business context. Together, you deliver contracts that enable successful EPC projects.

---

**END OF QUICK REFERENCE CHECKLIST v1.2**

**Last Updated:** November 11, 2025  
**Version:** 1.2  
**Optimized for:** EPC System Integrator - Prime, Sub, and Supplier positions + Channel Partners + Service Providers  
**Integration:** Pattern Library v1.2 (56 patterns) + Contract Review System v1.2

**Status:** Ã¢Å“â€¦ PRODUCTION READY
