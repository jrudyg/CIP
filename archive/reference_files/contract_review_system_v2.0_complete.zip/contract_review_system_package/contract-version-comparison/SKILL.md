---
name: contract-version-comparison
description: Generate professional .docx comparison reports for two contract versions with executive summary, 5-column analysis table, visual redlines (RED deletions, GREEN additions), business impact narratives, QA/QC validation, and alignment tracking. Use when user uploads two .docx contract versions and requests comparison analysis for internal review, negotiation preparation, or client presentation.
---

# Contract Version Comparison

## Overview

This skill compares two contract versions and generates a professional Word document with:
- Executive summary categorizing changes by impact level
- 5-column detailed comparison table
- Visual redlines (RED strikethrough deletions, GREEN bold additions)
- Business impact narratives in plain language
- Optional risk-framed recommendations
- QA/QC validation section with review tracking
- Alignment tracking against expected changes from risk reports

**Core value proposition:** Consistent, quality .docx generation with full QA/QC workflow support.

---

## When to Use This Skill

Use when user:
- Uploads two .docx files that are versions of the same contract
- Asks to compare contract versions
- Needs professional comparison report
- Requests redline analysis
- Wants to understand changes between versions
- Needs QA/QC validated comparison reports

---

## Scripts Available

### 1. compare_documents.py
Compares two contract .docx files and generates JSON output with detected changes.

```bash
python scripts/compare_documents.py v1.docx v2.docx output.json [--expected-changes expected.json]
```

**Features:**
- Section extraction and matching
- Change detection with impact classification
- Metadata tracking (generated_date, skill_version)
- QA/QC workflow fields
- Alignment tracking against expected changes

**Output includes:**
- `generated_date`: ISO 8601 timestamp
- `skill_version`: Version identifier
- `metadata`: QA/QC tracking fields (validated, qa_qc_complete, review_date, reviewed_by, counts)
- `alignment_summary`: matched/partial/not_applicable counts
- `missing_expected_changes`: Expected changes not found

### 2. generate_report.py
Generates professional Word document from comparison JSON.

```bash
python scripts/generate_report.py comparison.json output.docx [options]
```

**Options:**
- `--recommendations`: Include recommendations section
- `--qa-qc-complete`: Add QA/QC validation section
- `--reviewed-by NAME`: Reviewer name/role
- `--review-date DATE`: Review date (YYYY-MM-DD)
- `--flagged-items FILE`: JSON file with flagged items
- `--missing-changes FILE`: JSON file with missing changes

**QA/QC Section includes:**
- Quality Assurance Process description
- Validation Summary with counts
- Review Information
- Items Requiring Special Attention
- Risk Report Recommendations Not Implemented
- Methodology Notes

### 3. validate_entry.py
Validates individual comparison table entries against source documents.

```bash
python scripts/validate_entry.py entry.json v1.docx v2.docx [--verbose] [--output results.json]
```

**9-Point Validation:**
1. Section number exists in both documents
2. V1 text accuracy (95%+ fuzzy match)
3. V2 text accuracy (95%+ fuzzy match)
4. Text length within limits (500 chars)
5. All changes captured (no omissions)
6. Business impact present and clear
7. Impact classification valid
8. No formatting errors in redlines
9. Section title matches documents

**Exit codes:** 0 = valid, 1 = invalid

---

## Workflow

### Phase 1: Clarify Requirements

Ask user these questions **ONE AT A TIME** (wait for response before next):

1. **"What are the version identifiers?"**
   - Example: "V3 vs V4", "October 2025 vs November 2025"

2. **"What's your role in this agreement?"**
   - Options: Buyer, Seller, Vendor, Customer, Systems Integrator, Channel Partner, Service Provider

3. **"What's the comparison purpose?"**
   - Options: Internal review, Negotiation preparation, Client presentation, Due diligence

4. **"Which sections should I analyze?"**
   - Options: All substantive changes, Specific sections only, Exclude certain sections

5. **"Do you want recommendations?"**
   - Options: Yes (include Accept/Negotiate/Monitor guidance), No (just document changes)

6. **"Do you have expected changes from a risk report?"**
   - If yes: Request expected_changes.json for alignment tracking

---

### Phase 2: Extract and Compare Documents

**Run comparison:**
```bash
python scripts/compare_documents.py \
  uploaded_v1.docx \
  uploaded_v2.docx \
  comparison_results.json \
  --expected-changes expected_changes.json  # if provided
```

**Review output:**
- Check total_changes count
- Review alignment_summary if expected changes provided
- Note any missing_expected_changes

---

### Phase 3: Validate Critical Entries (Optional)

For high-stakes comparisons, validate critical entries:

```bash
# Extract entry from comparison JSON
python scripts/validate_entry.py \
  critical_entry.json \
  uploaded_v1.docx \
  uploaded_v2.docx \
  --verbose \
  --output validation_results.json
```

---

### Phase 4: Generate Report

**Basic report:**
```bash
python scripts/generate_report.py \
  comparison_results.json \
  comparison_report.docx \
  --recommendations
```

**With full QA/QC validation:**
```bash
python scripts/generate_report.py \
  comparison_results.json \
  comparison_report.docx \
  --recommendations \
  --qa-qc-complete \
  --reviewed-by "Senior Contract Analyst" \
  --review-date "2025-01-18" \
  --flagged-items flagged_items.json \
  --missing-changes missing_changes.json
```

---

### Phase 5: Deliver

**Output file naming:**
```
[DocName]_V[X]_to_V[Y]_Comparison_[YYYYMMDD].docx
```

Provide summary and download link to user.

---

## Impact Classification Rules

**CRITICAL:**
- Limitation of Liability
- Indemnification
- IP Ownership
- Compliance & Regulatory
- Insurance

**HIGH_PRIORITY:**
- Termination
- Warranty/Warranties
- Acceptance criteria
- SLA/Service Levels
- Fees/Pricing

**IMPORTANT:**
- Payment terms
- Invoice procedures
- Milestones

**OPERATIONAL:**
- Notice requirements
- Approval processes
- Reporting requirements

**ADMINISTRATIVE:**
- Minor administrative changes

---

## JSON File Formats

### expected_changes.json
```json
{
  "8.1": {
    "recommendation": "Add $100K minimum liability cap",
    "risk_rating": "CRITICAL"
  },
  "13.2": {
    "recommendation": "Add termination flexibility after 2 years",
    "risk_rating": "HIGH"
  }
}
```

### flagged_items.json
```json
[
  {
    "section_number": "8.1",
    "reason": "Potential conflict with Section 10.2"
  }
]
```

### missing_changes.json
```json
[
  {
    "section_number": "5.1",
    "recommendation": "Add default 30-day payment terms",
    "risk_rating": "MODERATE"
  }
]
```

### entry.json (for validation)
```json
{
  "section_number": "8.1",
  "section_title": "Limitation of Liability",
  "v1_text": "Original text...",
  "v2_text": "Modified text with ~~deletions~~ and **additions**...",
  "business_impact": "Business impact narrative...",
  "impact_classification": "CRITICAL"
}
```

---

## Dependencies

- Python 3.8+
- python-docx (`pip install python-docx`)

---

## Quality Principles

**Legal subject matter - accuracy non-negotiable**
- Validate section references against source documents
- Verify all changes captured
- Check redline formatting precision
- Use validation utility for critical entries

**Evidence-based recommendations**
- Risk-framed language (not imperative)
- Reasonable talking points
- Alignment tracking against expected changes

**Quality .docx generation is core value**
- Professional formatting
- Readable column widths
- QA/QC validation section when required
- Ready for distribution

---

## References

- `references/impact-classification.md` - Detailed classification logic
- `references/report-format.md` - Complete output specifications
- `references/validation-checklist.md` - Quality checks

---

**END OF SKILL.md**
