#!/usr/bin/env python3
"""
Validation utility for contract comparison table entries.

Usage:
    python validate_entry.py entry.json v1.docx v2.docx [--verbose] [--output results.json]

Performs 9-point QA/QC validation:
1. Section number exists in both documents
2. V1 text accuracy (95%+ fuzzy match)
3. V2 text accuracy (95%+ fuzzy match)
4. Text length within limits (500 chars)
5. All changes captured (no omissions)
6. Business impact present and clear
7. Impact classification valid
8. No formatting errors in redlines
9. Section title matches documents
"""

import json
import sys
import argparse
from pathlib import Path
from difflib import SequenceMatcher
import re

try:
    from docx import Document
except ImportError:
    print("[FAIL] python-docx not installed. Install with: pip install python-docx")
    sys.exit(1)

# Validation thresholds
TEXT_MATCH_THRESHOLD = 0.95
MAX_TEXT_LENGTH = 500
MIN_IMPACT_LENGTH = 50
VALID_CLASSIFICATIONS = ['CRITICAL', 'HIGH_PRIORITY', 'IMPORTANT', 'OPERATIONAL', 'ADMINISTRATIVE']


def load_entry(filepath):
    """Load table entry from JSON file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        return {'error': f"Failed to load entry: {e}"}


def extract_section_text(doc_path, section_number):
    """Extract text for a specific section from document."""
    try:
        doc = Document(doc_path)
        section_text = []
        in_section = False

        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue

            # Check if this is our section
            if section_number in text and (
                text.startswith(section_number) or
                f"Section {section_number}" in text or
                f"Article {section_number}" in text or
                re.match(rf'^{re.escape(section_number)}\s', text)
            ):
                in_section = True
                section_text.append(text)
                continue

            if in_section:
                # Check if we've reached next section
                if re.match(r'^\d+\.?\d*\s', text) and not text.startswith(section_number):
                    break
                section_text.append(text)

        return ' '.join(section_text) if section_text else None
    except Exception:
        return None


def fuzzy_match_score(text1, text2):
    """Calculate fuzzy match score between two texts."""
    text1 = ' '.join(text1.split())
    text2 = ' '.join(text2.split())
    return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()


def validate_section_number(entry, v1_doc, v2_doc):
    """Check 1: Section number exists in both documents."""
    section = entry.get('section_number', '')
    v1_text = extract_section_text(v1_doc, section)
    v2_text = extract_section_text(v2_doc, section)

    if v1_text is None:
        return {'check': 'section_number', 'status': 'fail',
                'message': f"Section {section} not found in V1 document"}
    if v2_text is None:
        return {'check': 'section_number', 'status': 'fail',
                'message': f"Section {section} not found in V2 document"}
    return {'check': 'section_number', 'status': 'pass',
            'message': f"Section {section} found in both documents"}


def validate_v1_accuracy(entry, v1_doc):
    """Check 2: V1 text matches document (95%+ fuzzy match)."""
    section = entry.get('section_number', '')
    entry_text = entry.get('v1_text', '')
    doc_text = extract_section_text(v1_doc, section)

    if doc_text is None:
        return {'check': 'v1_accuracy', 'status': 'fail',
                'message': "Could not extract V1 section text"}

    score = fuzzy_match_score(entry_text, doc_text[:len(entry_text) * 2])
    if score >= TEXT_MATCH_THRESHOLD:
        return {'check': 'v1_accuracy', 'status': 'pass',
                'message': f"V1 text matches document ({score:.1%} similarity)"}
    return {'check': 'v1_accuracy', 'status': 'fail',
            'message': f"V1 text mismatch ({score:.1%} similarity, need {TEXT_MATCH_THRESHOLD:.0%})",
            'detail': {'expected': doc_text[:200], 'got': entry_text[:200]}}


def validate_v2_accuracy(entry, v2_doc):
    """Check 3: V2 text matches document (95%+ fuzzy match)."""
    section = entry.get('section_number', '')
    entry_text = entry.get('v2_text', '')
    clean_text = entry_text.replace('~~', '').replace('**', '')
    doc_text = extract_section_text(v2_doc, section)

    if doc_text is None:
        return {'check': 'v2_accuracy', 'status': 'fail',
                'message': "Could not extract V2 section text"}

    score = fuzzy_match_score(clean_text, doc_text[:len(clean_text) * 2])
    if score >= TEXT_MATCH_THRESHOLD:
        return {'check': 'v2_accuracy', 'status': 'pass',
                'message': f"V2 text matches document ({score:.1%} similarity)"}
    return {'check': 'v2_accuracy', 'status': 'fail',
            'message': f"V2 text mismatch ({score:.1%} similarity, need {TEXT_MATCH_THRESHOLD:.0%})",
            'detail': {'expected': doc_text[:200], 'got': clean_text[:200]}}


def validate_text_length(entry):
    """Check 4: Text length within limits."""
    v1_len = len(entry.get('v1_text', ''))
    v2_len = len(entry.get('v2_text', ''))
    issues = []

    if v1_len > MAX_TEXT_LENGTH:
        issues.append(f"V1 text too long ({v1_len} > {MAX_TEXT_LENGTH} chars)")
    if v2_len > MAX_TEXT_LENGTH:
        issues.append(f"V2 text too long ({v2_len} > {MAX_TEXT_LENGTH} chars)")

    if issues:
        return {'check': 'text_length', 'status': 'fail', 'message': '; '.join(issues)}
    return {'check': 'text_length', 'status': 'pass',
            'message': f"Text lengths OK (V1: {v1_len}, V2: {v2_len})"}


def validate_completeness(entry, v1_doc, v2_doc):
    """Check 5: All changes captured (no omissions)."""
    section = entry.get('section_number', '')
    v1_text = extract_section_text(v1_doc, section)
    v2_text = extract_section_text(v2_doc, section)

    if v1_text is None or v2_text is None:
        return {'check': 'completeness', 'status': 'warning',
                'message': "Could not verify completeness (section extraction failed)"}

    entry_v1 = entry.get('v1_text', '')
    entry_v2 = entry.get('v2_text', '').replace('~~', '').replace('**', '')

    v1_coverage = len(entry_v1) / len(v1_text) if v1_text else 0
    v2_coverage = len(entry_v2) / len(v2_text) if v2_text else 0

    if v1_coverage < 0.5 and len(v1_text) > MAX_TEXT_LENGTH:
        return {'check': 'completeness', 'status': 'warning',
                'message': f"V1 text may be truncated ({v1_coverage:.0%} coverage)"}
    if v2_coverage < 0.5 and len(v2_text) > MAX_TEXT_LENGTH:
        return {'check': 'completeness', 'status': 'warning',
                'message': f"V2 text may be truncated ({v2_coverage:.0%} coverage)"}

    return {'check': 'completeness', 'status': 'pass',
            'message': f"Coverage adequate (V1: {v1_coverage:.0%}, V2: {v2_coverage:.0%})"}


def validate_business_impact(entry):
    """Check 6: Business impact present and clear."""
    impact = entry.get('business_impact', '')

    if not impact:
        return {'check': 'business_impact', 'status': 'fail', 'message': "Business impact missing"}
    if len(impact) < MIN_IMPACT_LENGTH:
        return {'check': 'business_impact', 'status': 'fail',
                'message': f"Business impact too brief ({len(impact)} chars, need {MIN_IMPACT_LENGTH}+)"}

    placeholders = ['TBD', 'TODO', '[', ']', 'PLACEHOLDER']
    if any(p in impact.upper() for p in placeholders):
        return {'check': 'business_impact', 'status': 'fail',
                'message': "Business impact contains placeholder text"}

    return {'check': 'business_impact', 'status': 'pass',
            'message': f"Business impact present ({len(impact)} chars)"}


def validate_impact_classification(entry):
    """Check 7: Impact classification valid."""
    classification = entry.get('impact_classification', '')

    if not classification:
        return {'check': 'impact_classification', 'status': 'fail',
                'message': "Impact classification missing"}
    if classification not in VALID_CLASSIFICATIONS:
        return {'check': 'impact_classification', 'status': 'fail',
                'message': f"Invalid classification '{classification}' (valid: {VALID_CLASSIFICATIONS})"}

    return {'check': 'impact_classification', 'status': 'pass',
            'message': f"Classification valid: {classification}"}


def validate_redline_formatting(entry):
    """Check 8: No formatting errors in redlines."""
    v2_text = entry.get('v2_text', '')
    issues = []

    if v2_text.count('~~') % 2 != 0:
        issues.append("Unmatched deletion markers (~~)")
    if v2_text.count('**') % 2 != 0:
        issues.append("Unmatched addition markers (**)")
    if '~~**' in v2_text or '**~~' in v2_text:
        issues.append("Nested redline markers detected")

    if issues:
        return {'check': 'redline_formatting', 'status': 'fail', 'message': '; '.join(issues)}
    return {'check': 'redline_formatting', 'status': 'pass', 'message': "Redline formatting valid"}


def validate_section_title(entry, v1_doc, v2_doc):
    """Check 9: Section title matches documents."""
    section = entry.get('section_number', '')
    title = entry.get('section_title', '')

    if not title:
        return {'check': 'section_title', 'status': 'fail', 'message': "Section title missing"}

    v1_heading = extract_section_text(v1_doc, section)
    v2_heading = extract_section_text(v2_doc, section)

    if v1_heading is None and v2_heading is None:
        return {'check': 'section_title', 'status': 'warning',
                'message': "Could not verify section title (section not found)"}

    heading_text = (v1_heading or '') + (v2_heading or '')
    title_match = title.lower() in heading_text.lower()

    if title_match:
        return {'check': 'section_title', 'status': 'pass',
                'message': f"Section title matches: {title}"}
    return {'check': 'section_title', 'status': 'warning',
            'message': f"Section title may not match document (got: '{title}')"}


def run_validation(entry, v1_doc_path, v2_doc_path, verbose=False):
    """Run all validation checks."""
    results = {
        'valid': False,
        'checks': [],
        'summary': {'pass': 0, 'fail': 0, 'warning': 0}
    }

    checks = [
        validate_section_number(entry, v1_doc_path, v2_doc_path),
        validate_v1_accuracy(entry, v1_doc_path),
        validate_v2_accuracy(entry, v2_doc_path),
        validate_text_length(entry),
        validate_completeness(entry, v1_doc_path, v2_doc_path),
        validate_business_impact(entry),
        validate_impact_classification(entry),
        validate_redline_formatting(entry),
        validate_section_title(entry, v1_doc_path, v2_doc_path)
    ]

    for check in checks:
        results['checks'].append(check)
        status = check['status']
        results['summary'][status] = results['summary'].get(status, 0) + 1

    results['valid'] = results['summary']['fail'] == 0
    return results


def main():
    parser = argparse.ArgumentParser(description='Validate contract comparison table entry')
    parser.add_argument('entry_file', help='Path to entry JSON file')
    parser.add_argument('v1_doc', help='Path to V1 contract document (.docx)')
    parser.add_argument('v2_doc', help='Path to V2 contract document (.docx)')
    parser.add_argument('--verbose', action='store_true', help='Show detailed results')
    parser.add_argument('--output', help='Save results to JSON file')

    args = parser.parse_args()

    # Load entry
    entry = load_entry(args.entry_file)
    if 'error' in entry:
        print(f"ERROR: {entry['error']}")
        sys.exit(1)

    # Run validation
    results = run_validation(entry, args.v1_doc, args.v2_doc, args.verbose)

    # Output results
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {args.output}")

    # Print summary
    print(f"\n{'='*60}")
    print(f"VALIDATION RESULTS - Section {entry.get('section_number', 'Unknown')}")
    print(f"{'='*60}\n")

    for check in results['checks']:
        status_symbol = {'pass': '[PASS]', 'fail': '[FAIL]', 'warning': '[WARN]'}[check['status']]
        print(f"{status_symbol} {check['check']}: {check['message']}")

        if args.verbose and 'detail' in check:
            print(f"  Detail: {check['detail']}")

    print(f"\n{'='*60}")
    print(f"Summary: {results['summary']['pass']} pass, "
          f"{results['summary']['fail']} fail, "
          f"{results['summary']['warning']} warning")
    print(f"Overall: {'VALID' if results['valid'] else 'INVALID'}")
    print(f"{'='*60}\n")

    sys.exit(0 if results['valid'] else 1)


if __name__ == '__main__':
    main()
