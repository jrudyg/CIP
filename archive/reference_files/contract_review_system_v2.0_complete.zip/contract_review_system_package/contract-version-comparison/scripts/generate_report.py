#!/usr/bin/env python3
"""
Report generation script for contract comparison.
Generates professional .docx comparison reports with redlines and impact analysis.
"""

import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List

try:
    from docx import Document
    from docx.shared import RGBColor, Pt, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
except ImportError:
    print("[FAIL] python-docx not installed. Install with: pip install python-docx")
    sys.exit(1)


class ReportGenerator:
    """Generates professional Word comparison reports."""

    # Color constants for redlines
    COLOR_DELETE_RED = RGBColor(255, 0, 0)  # #FF0000
    COLOR_ADD_GREEN = RGBColor(0, 176, 80)  # #00B050
    COLOR_HEADING = RGBColor(31, 73, 125)   # #1F497D

    def __init__(self, comparison_data: Dict, user_context: Dict = None):
        self.data = comparison_data
        self.context = user_context or {}
        self.doc = Document()
        self._setup_document_styles()

    def _setup_document_styles(self):
        """Configure document-wide styles."""
        # Set normal font
        style = self.doc.styles['Normal']
        font = style.font
        font.name = 'Calibri'
        font.size = Pt(11)

        # Set heading styles
        heading1 = self.doc.styles['Heading 1']
        heading1.font.name = 'Calibri'
        heading1.font.size = Pt(16)
        heading1.font.bold = True
        heading1.font.color.rgb = self.COLOR_HEADING

    def generate_report(self, output_path: str, include_recommendations: bool = False):
        """Generate complete comparison report."""
        print("[OK] Generating executive summary...")
        self._create_title_page()
        self._create_executive_summary()

        print("[OK] Building comparison table...")
        self._create_comparison_table(include_recommendations)

        if include_recommendations:
            print("[OK] Adding recommendations...")
            self._add_recommendations_section()

        print("[OK] Validating output...")
        if self._validate_document():
            self.doc.save(output_path)
            print(f"[OK] Report saved to: {output_path}")
        else:
            print("[FAIL] Validation failed - report may have issues")
            self.doc.save(output_path)

    def _create_title_page(self):
        """Create report title page."""
        # Title
        title = self.doc.add_heading('Contract Version Comparison Report', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Version identifiers
        v1_name = Path(self.data['v1_path']).stem
        v2_name = Path(self.data['v2_path']).stem

        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(f"{v1_name} → {v2_name}").bold = True

        # Date
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(f"Generated: {datetime.now().strftime('%B %d, %Y')}")

        # Context information if provided
        if self.context.get('role'):
            self.doc.add_paragraph()
            p = self.doc.add_paragraph()
            p.add_run(f"Prepared for: {self.context['role']}").italic = True
            if self.context.get('purpose'):
                p.add_run(f"\nPurpose: {self.context['purpose']}").italic = True

        self.doc.add_page_break()

    def _create_executive_summary(self):
        """Create executive summary with change counts by category."""
        self.doc.add_heading('Executive Summary', 1)

        # Count changes by impact level
        impact_counts = self._count_by_impact()

        # Summary table
        table = self.doc.add_table(rows=len(impact_counts) + 1, cols=2)
        table.style = 'Light Grid Accent 1'

        # Header row
        header_cells = table.rows[0].cells
        header_cells[0].text = 'Impact Category'
        header_cells[1].text = 'Number of Changes'

        for cell in header_cells:
            cell.paragraphs[0].runs[0].bold = True

        # Data rows
        row_idx = 1
        for impact, count in sorted(impact_counts.items()):
            row = table.rows[row_idx]
            row.cells[0].text = impact.replace('_', ' ').title()
            row.cells[1].text = str(count)
            row_idx += 1

        # Executive narrative
        self.doc.add_paragraph()
        self.doc.add_heading('Overview', 2)

        total_changes = self.data['total_changes']
        p = self.doc.add_paragraph()
        p.add_run(f"This comparison identified {total_changes} substantive changes ")
        p.add_run(f"between the two contract versions. ")

        if impact_counts.get('CRITICAL', 0) > 0:
            p.add_run(f"{impact_counts['CRITICAL']} changes are classified as CRITICAL ")
            p.add_run("and require immediate attention. ")

        # Key themes
        self.doc.add_heading('Key Change Themes', 2)
        themes = self._identify_themes()
        for theme in themes:
            self.doc.add_paragraph(theme, style='List Bullet')

    def _count_by_impact(self) -> Dict[str, int]:
        """Count changes by impact category."""
        counts = {}
        for change in self.data['changes']:
            impact = change['impact']
            counts[impact] = counts.get(impact, 0) + 1
        return counts

    def _identify_themes(self) -> List[str]:
        """Identify key themes from changes."""
        themes = []
        impact_counts = self._count_by_impact()

        if impact_counts.get('CRITICAL', 0) > 0:
            themes.append("Critical changes to liability, indemnification, or IP provisions")

        if impact_counts.get('HIGH_PRIORITY', 0) > 0:
            themes.append("Material operational and financial term modifications")

        if impact_counts.get('IMPORTANT', 0) > 0:
            themes.append("Payment and administrative procedure updates")

        if not themes:
            themes.append("Minor administrative and formatting changes")

        return themes

    def _create_comparison_table(self, include_recommendations: bool):
        """Create detailed 5-column comparison table."""
        self.doc.add_page_break()
        self.doc.add_heading('Detailed Comparison', 1)

        # Create table with 5 columns
        # Columns: # | Section/Recommendation | V[X] | V[Y] | Business Impact
        num_changes = len(self.data['changes'])
        table = self.doc.add_table(rows=num_changes + 1, cols=5)
        table.style = 'Light Grid Accent 1'

        # Set column widths (approximate percentages)
        # Column widths: 5%, 20%, 27.5%, 27.5%, 20%
        widths = [Inches(0.4), Inches(1.6), Inches(2.2), Inches(2.2), Inches(1.6)]
        for row in table.rows:
            for idx, width in enumerate(widths):
                row.cells[idx].width = width

        # Header row
        headers = ['#', 'Section / Recommendation', 'V1 Clause Language',
                   'V2 Clause Language', 'Business Impact']
        header_row = table.rows[0]
        for idx, header_text in enumerate(headers):
            cell = header_row.cells[idx]
            cell.text = header_text
            cell.paragraphs[0].runs[0].bold = True
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Data rows
        for row_idx, change in enumerate(self.data['changes'], start=1):
            row = table.rows[row_idx]

            # Column 1: Number
            row.cells[0].text = str(row_idx)
            row.cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

            # Column 2: Section title + recommendation
            section_cell = row.cells[1]
            section_para = section_cell.paragraphs[0]
            section_para.add_run(f"Section {change['section_number']}\n").bold = True
            section_para.add_run(change['section_title'])

            if include_recommendations:
                rec = self._generate_recommendation(change)
                section_para.add_run(f"\n\nRecommendation: {rec['tier']}\n").bold = True
                section_para.add_run(f"{rec['rationale']}")

            if change.get('tie_breaker'):
                section_para.add_run(" *").bold = True

            # Column 3: V1 content
            v1_cell = row.cells[2]
            v1_para = v1_cell.paragraphs[0]
            v1_text = change['v1_content'][:500]  # Limit length
            v1_para.add_run(v1_text if v1_text else "[New Section]").italic = not v1_text

            # Column 4: V2 content with redlines
            v2_cell = row.cells[3]
            self._add_redline_content(v2_cell, change['v1_content'], change['v2_content'])

            # Column 5: Business impact narrative
            impact_cell = row.cells[4]
            impact_para = impact_cell.paragraphs[0]
            impact_narrative = self._generate_business_impact(change)
            impact_para.add_run(impact_narrative)

    def _add_redline_content(self, cell, v1_content: str, v2_content: str):
        """Add redlined content to cell (RED deletions, GREEN additions)."""
        para = cell.paragraphs[0]

        # Simple diff: show deletions and additions
        # For production, would use more sophisticated diff algorithm

        if not v1_content:
            # New content - all green
            run = para.add_run(v2_content[:500])
            run.bold = True
            run.font.color.rgb = self.COLOR_ADD_GREEN
            return

        if not v2_content:
            # Deleted content - all red strikethrough
            run = para.add_run(v1_content[:500])
            run.font.strike = True
            run.font.color.rgb = self.COLOR_DELETE_RED
            return

        # Modified content - show simplified redline
        # In production, would use difflib for word-by-word comparison
        if v1_content != v2_content:
            # Show deletion
            deleted_run = para.add_run("[Deleted: " + v1_content[:100] + "...]\n")
            deleted_run.font.strike = True
            deleted_run.font.color.rgb = self.COLOR_DELETE_RED

            # Show addition
            added_run = para.add_run(v2_content[:400])
            added_run.bold = True
            added_run.font.color.rgb = self.COLOR_ADD_GREEN
        else:
            para.add_run(v2_content[:500])

    def _generate_business_impact(self, change: Dict) -> str:
        """Generate business impact narrative for a change."""
        impact = change['impact']
        section_title = change['section_title']
        change_type = change.get('change_type', 'modification')

        # Template-based narrative generation
        if impact == 'CRITICAL':
            if 'liability' in section_title.lower():
                return (f"This modification to liability provisions directly affects risk exposure "
                       f"and potential financial obligations. Requires legal review and risk assessment "
                       f"before acceptance.")
            elif 'indemnif' in section_title.lower():
                return (f"Changes to indemnification obligations may significantly impact risk allocation "
                       f"between parties. Evaluate implications for insurance coverage and financial exposure.")
            else:
                return (f"Critical change affecting core contractual protections or obligations. "
                       f"Immediate review required to assess business risk and strategic implications.")

        elif impact == 'HIGH_PRIORITY':
            return (f"Material change affecting operational or financial terms. "
                   f"Review impact on business operations, budget, and timeline commitments.")

        elif impact == 'IMPORTANT':
            return (f"Substantive modification requiring attention. Assess impact on cash flow, "
                   f"administrative procedures, or deliverable requirements.")

        elif impact == 'OPERATIONAL':
            return (f"Operational change affecting day-to-day contract administration. "
                   f"Update internal procedures and stakeholder communications accordingly.")

        else:
            return f"Administrative update with minimal business impact. Note for records."

    def _generate_recommendation(self, change: Dict) -> Dict:
        """Generate risk-framed recommendation for a change."""
        impact = change['impact']

        if impact == 'CRITICAL':
            return {
                'tier': 'CRITICAL ATTENTION',
                'rationale': 'Significant risk exposure. Recommend negotiation or executive escalation.'
            }
        elif impact == 'HIGH_PRIORITY':
            return {
                'tier': 'RECOMMEND REVIEW',
                'rationale': 'Moderate concern. Consider negotiating alternative language or accept with mitigation plan.'
            }
        else:
            return {
                'tier': 'MONITOR',
                'rationale': 'Low risk. Accept and track for compliance.'
            }

    def _add_recommendations_section(self):
        """Add recommendations summary section."""
        self.doc.add_page_break()
        self.doc.add_heading('Recommendations Summary', 1)

        p = self.doc.add_paragraph()
        p.add_run("The following recommendations are provided based on risk-framed analysis of identified changes. ")
        p.add_run("These are suggested talking points and should be evaluated in context of your specific business objectives.")

        # Group by recommendation tier
        critical = [c for c in self.data['changes'] if c['impact'] == 'CRITICAL']
        high_priority = [c for c in self.data['changes'] if c['impact'] == 'HIGH_PRIORITY']

        if critical:
            self.doc.add_heading('Critical Attention Required', 2)
            for change in critical:
                p = self.doc.add_paragraph(style='List Bullet')
                p.add_run(f"Section {change['section_number']}: {change['section_title']}\n").bold = True
                p.add_run(self._generate_business_impact(change))

        if high_priority:
            self.doc.add_heading('Recommend Review', 2)
            for change in high_priority:
                p = self.doc.add_paragraph(style='List Bullet')
                p.add_run(f"Section {change['section_number']}: {change['section_title']}\n").bold = True
                p.add_run(self._generate_business_impact(change))

    def _validate_document(self) -> bool:
        """Validate document before saving."""
        # Basic validation checks
        if not self.doc.paragraphs:
            print("[FAIL] Document has no content")
            return False

        if not self.doc.tables:
            print("[FAIL] Document missing comparison table")
            return False

        expected_changes = self.data['total_changes']
        table_rows = len(self.doc.tables[1].rows) - 1  # Minus header row

        if table_rows != expected_changes:
            print(f"[WARN] Table row count ({table_rows}) doesn't match changes ({expected_changes})")

        return True

    def generate_qa_qc_section(self, args):
        """Generate QA/QC Validation Notes section."""
        self.doc.add_page_break()
        heading = self.doc.add_heading('QA/QC Validation Notes', 1)

        # Quality Assurance Process
        self.doc.add_heading('Quality Assurance Process', 2)
        process_text = (
            'This comparison report was generated using automated comparison tools and '
            'validated through manual QA/QC review. Each change was reviewed for accuracy, '
            'completeness, and alignment with risk assessment recommendations.'
        )
        self.doc.add_paragraph(process_text)

        # Validation Summary
        self.doc.add_heading('Validation Summary', 2)
        metadata = self.data.get('metadata', {})

        summary_items = [
            f"Total changes identified: {self.data.get('total_changes', 0)}",
            f"Entries approved without modification: {metadata.get('approved_count', 0)}",
            f"Entries corrected during QA/QC: {metadata.get('modified_count', 0)}",
            f"Entries flagged for attention: {metadata.get('flagged_count', 0)}",
            f"Entries rejected and regenerated: {metadata.get('rejected_count', 0)}"
        ]

        for item in summary_items:
            self.doc.add_paragraph(item, style='List Bullet')

        # Review Information
        if args.reviewed_by or args.review_date:
            self.doc.add_heading('Review Information', 2)
            if args.reviewed_by:
                self.doc.add_paragraph(f"Reviewed by: {args.reviewed_by}")
            if args.review_date:
                self.doc.add_paragraph(f"Review date: {args.review_date}")

        # Flagged Items
        if args.flagged_items:
            try:
                with open(args.flagged_items, 'r') as f:
                    flagged = json.load(f)
                if flagged:
                    self.doc.add_heading('Items Requiring Special Attention', 2)
                    for item in flagged:
                        section = item.get('section_number', 'Unknown')
                        reason = item.get('reason', 'No reason provided')
                        self.doc.add_paragraph(f"Section {section}: {reason}", style='List Bullet')
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"[WARN] Could not load flagged items: {e}")

        # Missing Changes
        if args.missing_changes:
            try:
                with open(args.missing_changes, 'r') as f:
                    missing = json.load(f)
                if missing:
                    self.doc.add_heading('Risk Report Recommendations Not Implemented', 2)
                    for item in missing:
                        section = item.get('section_number', 'Unknown')
                        recommendation = item.get('recommendation', 'No recommendation provided')
                        self.doc.add_paragraph(f"Section {section}: {recommendation}", style='List Bullet')
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"[WARN] Could not load missing changes: {e}")

        # Methodology Notes
        self.doc.add_heading('Methodology Notes', 2)
        methodology_text = (
            'This report documents substantive changes only; formatting and minor '
            'grammatical changes excluded. Business impact narratives reflect typical '
            'commercial scenarios and should be validated against specific transaction context. '
            'Section numbering verified against source documents during QA/QC.'
        )
        self.doc.add_paragraph(methodology_text)


def load_comparison_data(json_path: str) -> Dict:
    """Load comparison results from JSON file."""
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def main():
    """Command-line interface."""
    parser = argparse.ArgumentParser(description='Generate contract comparison report')
    parser.add_argument('comparison_json', help='Path to comparison JSON file')
    parser.add_argument('output', nargs='?', default='comparison_report.docx',
                        help='Output .docx path (default: comparison_report.docx)')
    parser.add_argument('--recommendations', action='store_true',
                        help='Include recommendations section')
    parser.add_argument('--qa-qc-complete', action='store_true',
                        help='Mark report as QA/QC validated')
    parser.add_argument('--reviewed-by', type=str,
                        help='Name/role of person who reviewed')
    parser.add_argument('--review-date', type=str,
                        help='Date of QA/QC review (YYYY-MM-DD)')
    parser.add_argument('--flagged-items', type=str,
                        help='Path to JSON file with flagged items')
    parser.add_argument('--missing-changes', type=str,
                        help='Path to JSON file with missing changes')

    args = parser.parse_args()

    try:
        print(f"[OK] Loading comparison data from: {args.comparison_json}")
        data = load_comparison_data(args.comparison_json)

        print("[OK] Initializing report generator...")
        generator = ReportGenerator(data)

        generator.generate_report(args.output, args.recommendations)

        # Add QA/QC section if requested
        if args.qa_qc_complete:
            print("[OK] Adding QA/QC validation section...")
            generator.generate_qa_qc_section(args)
            generator.doc.save(args.output)

        print("\n" + "=" * 60)
        print("REPORT GENERATION COMPLETE")
        print("=" * 60)
        print(f"Output: {args.output}")
        print(f"Changes documented: {data['total_changes']}")
        print(f"Recommendations included: {'Yes' if args.recommendations else 'No'}")
        print(f"QA/QC section included: {'Yes' if args.qa_qc_complete else 'No'}")
        print("=" * 60)

        return 0

    except FileNotFoundError as e:
        print(f"[FAIL] File not found: {e}")
        return 1
    except Exception as e:
        print(f"[FAIL] Error generating report: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
