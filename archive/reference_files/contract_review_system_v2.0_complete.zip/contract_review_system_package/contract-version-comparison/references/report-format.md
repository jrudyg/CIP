# Report Format Specifications

## Document Structure

### 1. Title Page

**Required Elements:**
- Document title: "Contract Version Comparison Report"
- Version identifiers: "[V1 Name] → [V2 Name]"
- Generation date: "Generated: [Month DD, YYYY]"
- Optional context: User role, purpose

**Formatting:**
- Title: Heading 1, centered, bold
- Version identifiers: Centered, bold
- Date: Centered, normal weight
- Context: Italic, left-aligned

---

### 2. Executive Summary

**Section Components:**

**2.1 Change Summary Table**
- 2 columns: Impact Category | Number of Changes
- Table style: Light Grid Accent 1
- Header row: Bold
- Rows sorted by impact severity (CRITICAL first)

**2.2 Executive Overview Narrative**
- 2-3 paragraphs summarizing key findings
- Lead with total change count
- Highlight CRITICAL changes if present
- Professional, concise tone

**2.3 Key Change Themes**
- Bulleted list (3-5 items)
- High-level categorization of change patterns
- Focus on business implications, not technical details

**Example themes:**
- "Critical changes to liability, indemnification, or IP provisions"
- "Material operational and financial term modifications"
- "Payment and administrative procedure updates"

---

### 3. Detailed Comparison Table

**Table Structure: 5 Columns**

| # | Section / Recommendation | V[X] Clause Language | V[Y] Clause Language | Business Impact |
|---|---|---|---|---|

**Column Specifications:**

**Column 1: Sequential Number (#)**
- Width: 5% (0.4 inches)
- Alignment: Center
- Content: Row number (1, 2, 3...)

**Column 2: Section / Recommendation**
- Width: 20% (1.6 inches)
- Alignment: Left
- Content structure:
  ```
  Section [Number] (bold)
  [Section Title] (normal)

  Recommendation: [TIER] (bold, if recommendations enabled)
  [Rationale] (normal, if recommendations enabled)
  ```
- Tie-breaker indicator: Asterisk (*) if confidence < 85%

**Column 3: V[X] Clause Language**
- Width: 27.5% (2.2 inches)
- Alignment: Left
- Content: Original clause text from V1
- Special case: "[New Section]" in italics if section didn't exist in V1
- Text limit: 500 characters (truncate with "...")

**Column 4: V[Y] Clause Language**
- Width: 27.5% (2.2 inches)
- Alignment: Left
- Content: Revised clause text from V2 with **redlines**
- Redline formatting:
  - **Deletions:** RED (#FF0000), strikethrough
  - **Additions:** GREEN (#00B050), bold
- Text limit: 500 characters

**Column 5: Business Impact**
- Width: 20% (1.6 inches)
- Alignment: Left
- Content: 2-4 sentence business impact narrative
- Plain language, focus on implications

**Table Styling:**
- Table style: Light Grid Accent 1
- Header row: Bold, centered
- Data rows: Normal weight, left-aligned (except #)
- Cell padding: Default
- Row height: Auto-fit content

---

## Redline Formatting Standards

### Color Codes (Exact RGB)
- **Deletion RED:** RGB(255, 0, 0) = #FF0000
- **Addition GREEN:** RGB(0, 176, 80) = #00B050
- **Heading Blue:** RGB(31, 73, 125) = #1F497D

### Deletion Formatting
```python
run.font.strike = True  # Strikethrough
run.font.color.rgb = RGBColor(255, 0, 0)  # RED
```

### Addition Formatting
```python
run.bold = True  # Bold
run.font.color.rgb = RGBColor(0, 176, 80)  # GREEN
```

### Redline Display Methods

**Method 1: Inline Redline (Preferred)**
- Show deleted and added text inline
- Example: "~~Payment due Net 30~~ **Payment due Net 45** days"

**Method 2: Sequential Redline**
- Show deletion first, then addition
- Example:
  ```
  [Deleted: Payment due Net 30 days]
  Payment due Net 45 days
  ```

**Method 3: Side-by-Side (Table Columns)**
- V1 column: Original text (no color)
- V2 column: Redlined changes
- This is the standard approach for comparison table

---

## Business Impact Narrative Standards

### Writing Guidelines

**Focus Areas:**
- Financial implications
- Timeline impacts
- Relationship dynamics
- Operational changes
- Risk exposure
- Strategic considerations

**Style Requirements:**
- Plain language (no legalese)
- Concrete and specific (not vague)
- 2-4 sentences maximum
- Active voice
- Professional tone

### Impact Narrative Templates

**CRITICAL Impact:**
```
"This modification to [provision type] directly affects [specific risk/obligation].
[Quantify exposure if possible]. Requires [specific action] before acceptance."
```

**HIGH PRIORITY Impact:**
```
"Material change affecting [operational/financial area]. Review impact on
[specific business function], [budget/timeline], and [stakeholder commitments]."
```

**IMPORTANT Impact:**
```
"Substantive modification requiring attention. Assess impact on [specific area]
and update [relevant procedures/stakeholders] accordingly."
```

**OPERATIONAL Impact:**
```
"Operational change affecting [specific process]. Update internal procedures
and stakeholder communications as needed."
```

**ADMINISTRATIVE Impact:**
```
"Administrative update with minimal business impact. Note for records."
```

### Good vs. Bad Examples

**BAD (Vague):**
> "This is a significant change that may have important implications."

**GOOD (Specific):**
> "Extending payment terms from Net 30 to Net 60 creates a 30-day cash flow delay,
> impacting working capital by approximately $X per invoice cycle."

**BAD (Legal jargon):**
> "The indemnification provision's modification vis-à-vis the aforementioned parties..."

**GOOD (Plain language):**
> "This change shifts indemnification responsibility from Vendor to Customer for
> third-party IP claims, increasing Customer's legal exposure and insurance requirements."

---

## Recommendation Framework

### Three-Tier Structure

**Tier 1: CRITICAL ATTENTION**
- Use for: CRITICAL impact changes
- Standard rationale: "Significant risk exposure. Recommend negotiation or executive escalation."
- Indicates: Major business risk, requires decision-maker involvement

**Tier 2: RECOMMEND REVIEW**
- Use for: HIGH_PRIORITY impact changes
- Standard rationale: "Moderate concern. Consider negotiating alternative language or accept with mitigation plan."
- Indicates: Material change, business judgment needed

**Tier 3: MONITOR**
- Use for: IMPORTANT, OPERATIONAL, ADMINISTRATIVE changes
- Standard rationale: "Low risk. Accept and track for compliance."
- Indicates: Routine change, administrative tracking sufficient

### Recommendation Display Format

**In Table (Column 2):**
```
Section 5.3
Limitation of Liability

Recommendation: CRITICAL ATTENTION
Significant risk exposure. Recommend negotiation
or executive escalation.
```

**In Summary Section:**
```
### Critical Attention Required

• Section 5.3: Limitation of Liability
  This modification to liability provisions directly affects risk
  exposure and potential financial obligations. Requires legal review
  and risk assessment before acceptance.
```

---

## Professional Language Standards

### Tone Requirements
- **Objective:** State facts without emotional language
- **Professional:** Business-appropriate vocabulary
- **Risk-framed:** Focus on implications, not commands
- **Reasonable:** Suggest, don't dictate

### Prohibited Language
- ❌ "You MUST negotiate this"
- ❌ "This is terrible for you"
- ❌ "Never accept this change"
- ❌ "Absolutely critical"

### Preferred Language
- ✅ "Recommend negotiation"
- ✅ "Consider implications for"
- ✅ "May affect business risk"
- ✅ "Requires attention"

---

## File Naming Convention

**Format:**
```
[ContractName]_V[X]_to_V[Y]_Comparison_[YYYYMMDD].docx
```

**Examples:**
- `MSA_V3_to_V4_Comparison_20250118.docx`
- `ServiceAgreement_V1_to_V2_Comparison_20250118.docx`
- `PurchaseOrder_Original_to_Revised_Comparison_20250118.docx`

**Rules:**
- No spaces in version identifiers (use underscores)
- Date format: YYYYMMDD (sortable)
- Extension: Always `.docx`

---

## Font and Typography Standards

### Font Specifications
- **Body text:** Calibri, 11pt
- **Headings:**
  - Heading 1: Calibri, 16pt, Bold, Color #1F497D
  - Heading 2: Calibri, 13pt, Bold
- **Table text:** Calibri, 10pt (auto-sized for readability)

### Spacing
- **Line spacing:** 1.15 (default)
- **Paragraph spacing:** 0pt before, 8pt after
- **Table cell padding:** Default (0.08" all sides)

### Margins
- **Page margins:** 1" all sides (default)
- **Adjust for tables:** May reduce to 0.75" if table width requires

---

## Page Layout

### Orientation
- **Default:** Portrait
- **Optional Landscape:** If table doesn't fit portrait with readable font

### Page Breaks
- After title page
- Before "Detailed Comparison" section
- Before "Recommendations Summary" (if included)

### Headers/Footers
- **Optional:** Add page numbers in footer (centered)
- **Optional:** Add "CONFIDENTIAL" in header if needed

---

## Quality Standards Summary

**Report must include:**
- ✅ All substantive changes captured in table
- ✅ Section references accurate and verified
- ✅ Redline formatting applied correctly (RED/GREEN)
- ✅ Business impact narratives complete (2-4 sentences each)
- ✅ Recommendations present if requested
- ✅ Executive summary totals match table row count
- ✅ Impact classifications follow rules from impact-classification.md
- ✅ Professional formatting throughout
- ✅ No company name changes included (unless entity actually changed)

**Report must NOT include:**
- ❌ Formatting-only changes (unless specified by user)
- ❌ Company name substitutions (unless entity changed)
- ❌ Typo corrections
- ❌ Grammar fixes without substantive meaning change

---

**END OF REPORT FORMAT SPECIFICATIONS**
