# Validation Checklist

## Pre-Generation Validation

### Document Extraction Validation

**Before comparing documents:**

- [ ] **V1 document accessible**
  - File exists at specified path
  - File is valid .docx format
  - File opens without errors

- [ ] **V2 document accessible**
  - File exists at specified path
  - File is valid .docx format
  - File opens without errors

- [ ] **Document type verification**
  - Confirm both are versions of same agreement
  - Alert user if document types appear different
  - Get explicit confirmation before proceeding

- [ ] **Content extraction successful**
  - V1 extracted without errors
  - V2 extracted without errors
  - Section structure detected in both
  - Minimum 1 section found in each document

---

## Section Matching Validation

### Content-Based Matching

- [ ] **Section pairing accurate**
  - Sections matched by content, not section numbers
  - Confidence scores calculated for all matches
  - Low-confidence matches flagged (< 85%)

- [ ] **Tie-breaker cases identified**
  - Matches with confidence < 85% marked with asterisk (*)
  - User notified of tie-breaker cases
  - Latest version (V2) used as definitive in ties

- [ ] **New sections detected**
  - Sections in V2 not present in V1 identified
  - Marked appropriately in comparison table
  - Impact classification applied

- [ ] **Deleted sections detected**
  - Sections in V1 not present in V2 identified
  - Marked appropriately in comparison table
  - Impact classification applied

---

## Change Detection Validation

### Substantive Changes Only

- [ ] **Company name changes filtered**
  - Anonymization tokens detected ([COMPANY_A], [CLIENT], etc.)
  - Name substitutions auto-handled if confidence ≥ 85%
  - Low-confidence cases flagged for user review

- [ ] **Formatting changes ignored**
  - Font changes not reported as substantive
  - Spacing variations ignored
  - Section renumbering ignored (content-based matching handles this)

- [ ] **Typos and grammar ignored**
  - Minor spelling corrections filtered
  - Grammar fixes without meaning change filtered
  - Only substantive differences reported

- [ ] **Date variations handled**
  - Date format changes ignored
  - Date value changes flagged if substantive

---

## Impact Classification Validation

### Classification Accuracy

- [ ] **Rules applied correctly**
  - Classification follows references/impact-classification.md
  - Priority hierarchy respected:
    1. Limitation of Liability → CRITICAL
    2. Indemnification → CRITICAL
    3. IP Ownership → CRITICAL
    4. Compliance & Regulatory → CRITICAL
    5. Insurance → CRITICAL
    6. Operational → HIGH_PRIORITY
    7. Financial → HIGH_PRIORITY
    8. Payment terms → Context-dependent

- [ ] **Context-dependent classifications evaluated**
  - Payment terms analyzed for SOW tie
  - Payment terms analyzed for flowdown requirements
  - Appropriate classification assigned based on context

- [ ] **Ambiguous cases handled**
  - AI judgment applied for unclear cases
  - When uncertain, classified one level higher for safety
  - Rationale documented in business impact narrative

---

## Business Impact Narrative Validation

### Narrative Quality

- [ ] **All changes have narratives**
  - Every row in comparison table has business impact
  - No empty or placeholder narratives
  - Narratives complete before report generation

- [ ] **Narrative length appropriate**
  - 2-4 sentences per narrative
  - Not too brief (< 1 sentence)
  - Not too verbose (> 5 sentences)

- [ ] **Plain language used**
  - No legal jargon
  - Concrete and specific
  - Business-focused, not technical

- [ ] **Focus areas covered**
  - Financial implications addressed if relevant
  - Timeline impacts noted if applicable
  - Risk exposure quantified when possible
  - Operational changes explained

- [ ] **Examples reviewed for quality**
  - Sample narratives presented to user (strategic QA gate)
  - User approves approach before bulk generation
  - Adjustments made based on feedback

---

## Report Generation Validation

### Document Structure

- [ ] **Title page complete**
  - Document title present
  - Version identifiers correct
  - Generation date accurate
  - Context information included if provided

- [ ] **Executive summary complete**
  - Change summary table present
  - Impact category counts accurate
  - Executive narrative included (2-3 paragraphs)
  - Key themes listed (3-5 bullet points)

- [ ] **Comparison table complete**
  - Table has 5 columns
  - Header row formatted correctly (bold, centered)
  - All changes included in table
  - Row count matches total_changes count

---

### Table Content Validation

- [ ] **Column 1: Sequential numbering**
  - Numbers sequential (1, 2, 3...)
  - Centered alignment
  - No gaps or duplicates

- [ ] **Column 2: Section information**
  - Section number present
  - Section title accurate
  - Recommendations included if requested
  - Tie-breaker asterisks (*) where appropriate

- [ ] **Column 3: V1 content**
  - Original clause text included
  - "[New Section]" for new sections
  - Text truncated appropriately if > 500 chars
  - Formatting readable

- [ ] **Column 4: V2 content with redlines**
  - Redline formatting applied
  - Deletions: RED (#FF0000), strikethrough
  - Additions: GREEN (#00B050), bold
  - Text truncated appropriately if > 500 chars

- [ ] **Column 5: Business impact**
  - Narrative present for every row
  - 2-4 sentences
  - Plain language
  - Specific and actionable

---

### Redline Formatting Validation

- [ ] **Color accuracy**
  - Deletion RED: RGB(255, 0, 0) = #FF0000
  - Addition GREEN: RGB(0, 176, 80) = #00B050
  - No other colors used for redlines

- [ ] **Deletion formatting**
  - Strikethrough applied
  - RED color applied
  - Text readable

- [ ] **Addition formatting**
  - Bold applied
  - GREEN color applied
  - Text readable

- [ ] **Mixed changes handled**
  - Both deletions and additions shown
  - Clear visual distinction
  - Sequence logical (deleted first, then added)

---

## Recommendations Validation

### Recommendation Content (if requested)

- [ ] **Recommendations included in table**
  - Column 2 includes recommendation tier
  - Rationale provided
  - Format consistent

- [ ] **Recommendation tiers appropriate**
  - CRITICAL ATTENTION for CRITICAL impact
  - RECOMMEND REVIEW for HIGH_PRIORITY impact
  - MONITOR for IMPORTANT/OPERATIONAL/ADMINISTRATIVE

- [ ] **Recommendations summary section**
  - Summary section present if recommendations requested
  - Changes grouped by tier
  - Narratives included for each change

- [ ] **Risk-framed language used**
  - "Recommend" not "Must"
  - "Consider" not "You need to"
  - Reasonable talking points, not commands

---

## Output Quality Validation

### File Output

- [ ] **File naming correct**
  - Format: [ContractName]_V[X]_to_V[Y]_Comparison_[YYYYMMDD].docx
  - No spaces in problematic locations
  - Date format correct (YYYYMMDD)

- [ ] **File location correct**
  - Saved to outputs directory
  - Path accessible to user
  - File permissions correct

- [ ] **File opens successfully**
  - .docx file valid
  - Opens in Microsoft Word without errors
  - Opens in LibreOffice/Google Docs (compatibility check)

---

### Document Readability

- [ ] **Table columns readable**
  - Column widths appropriate
  - Text not excessively cramped
  - Font size legible (≥ 10pt)
  - Row heights auto-fit content

- [ ] **Page layout appropriate**
  - Portrait orientation (or landscape if needed)
  - Margins appropriate (1" standard)
  - Page breaks in logical locations
  - No orphaned rows

- [ ] **Formatting professional**
  - Consistent font usage
  - Proper heading hierarchy
  - Table styling appropriate
  - No formatting glitches

---

## Cross-Validation Checks

### Data Integrity

- [ ] **Section references accurate**
  - All section numbers match source documents
  - Section titles verbatim from source
  - No invented or hallucinated sections

- [ ] **Change counts match**
  - Executive summary total = table row count
  - Impact category counts sum to total
  - No missing or duplicate changes

- [ ] **Impact distribution reasonable**
  - Not all changes marked CRITICAL (unlikely)
  - Distribution follows expected patterns
  - Outliers reviewed and justified

---

## Final Quality Gates

### Before Delivery

- [ ] **Comprehensive review**
  - Spot-check 10% of changes for accuracy
  - Verify 3 random section references against source
  - Confirm redline formatting in 5 random rows
  - Review 3 business impact narratives for quality

- [ ] **User confirmation checkpoints**
  - Document type verified and confirmed
  - Sample narratives approved
  - Recommendations preference confirmed
  - Scope confirmed (all sections vs. specific sections)

- [ ] **Error handling**
  - No unhandled exceptions during generation
  - All errors logged and reported
  - Recovery options provided if failures occur

- [ ] **Session continuity**
  - Checkpoints saved at key stages
  - Recovery possible if session breaks
  - User context preserved

---

## Recovery and Error Handling

### If Validation Fails

**Stop immediately and:**
1. Report specific validation failure(s)
2. Provide details on what failed
3. Offer recovery options:
   - Re-run specific validation step
   - Adjust parameters and retry
   - Manual review and override
   - Abort and restart process

**Do not:**
- Continue with known errors
- Deliver incomplete or incorrect reports
- Guess or hallucinate missing data
- Override validation without user approval

---

## Validation Logging

### Required Log Entries

For each validation run, log:
- Timestamp
- Validation stage
- Pass/Fail status
- Error details (if failed)
- Recovery action taken (if applicable)

**Example log entry:**
```
[2025-01-18 23:55:00] Section Matching Validation
Status: PASS
Sections matched: 42
Low confidence matches: 3 (flagged with *)
New sections detected: 1
```

---

## Quality Metrics

### Success Criteria

**Report passes validation if:**
- ✅ All pre-generation checks pass
- ✅ Section matching confidence ≥ 85% (or flagged)
- ✅ All substantive changes captured
- ✅ Impact classifications accurate
- ✅ Business impact narratives complete
- ✅ Redline formatting correct (RED/GREEN)
- ✅ Table structure valid (5 columns, all rows)
- ✅ Document opens successfully
- ✅ Professional appearance maintained
- ✅ File delivered to correct location

**Report fails validation if:**
- ❌ Missing changes detected
- ❌ Section references incorrect
- ❌ Redline formatting broken
- ❌ Missing business impact narratives
- ❌ Impact classifications violate rules
- ❌ Document won't open or has errors
- ❌ Unprofessional formatting
- ❌ Data integrity issues

---

**END OF VALIDATION CHECKLIST**
