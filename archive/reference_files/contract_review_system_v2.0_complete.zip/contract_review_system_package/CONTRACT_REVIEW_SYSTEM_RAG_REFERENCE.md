# CONTRACT REVIEW SYSTEM v1.1 - RAG REFERENCE GUIDE

**Last Updated:** October 19, 2025  
**Status:** Production Ready  
**Purpose:** Complete system reference for RAG retrieval and AI assistant operations

---

## QUICK SYSTEM IDENTIFICATION

### Current Version: v1.1 (EPC Optimized)
- **Release Date:** October 18, 2025
- **Pattern Count:** 52 distinct patterns + 4 coordination clusters
- **Optimization Focus:** EPC System Integrator (Quality + Schedule + Margin)
- **File Size:** 122KB main library
- **Status:** âœ… Production Ready

### Version History
- **v1.0:** Original 33 core patterns (prefix numbering: LOL-1, IND-2, etc.)
- **v1.1:** Current - 52 patterns + clusters (hierarchical: 2.1.1, 3.1.2, etc.)

---

## CORE SYSTEM FILES (4 PRIMARY)

### 1. 00_PROJECT_INSTRUCTIONS_v1.1_EPC_OPTIMIZED.docx
**Purpose:** Claude's primary operating instructions  
**Size:** 21KB  
**Key Content:**
- Role definition (in-house legal counsel for EPC System Integrator)
- Core operating principles (Accuracy First, Business Focus, User Guidance)
- Auto-start protocol (3 questions on contract upload)
- Workflow requirements (clause-by-clause with QA/QC)
- Critical quality checks (accuracy, formatting, business, EPC-specific)
- Context window management procedures
- Emergency procedures (dealbreaker detection, section not found, etc.)

**Priority Rules:**
1. Accuracy over speed (98%+ section number verification)
2. User is ultimate QA/QC (never proceed without response)
3. One clause at a time (in original contract order)
4. Ask when uncertain (never guess)
5. Format perfectly (strikethrough/inline code precision)

### 2. 01_CONTRACT_REVIEW_SYSTEM_v1.1_EPC.docx
**Purpose:** 10-step process methodology  
**Key Content:**
- Step 1: Context Capture (position/leverage/narrative)
- Step 2: Contract Structure Mapping (section numbers, headings)
- Step 3: Holistic Risk Assessment (risk matrix by clause)
- Step 4: Sequential Clause Processing (exact quotes, formatting)
- Step 5: Cascade Detection (dependency impacts)
- Step 6: Single Clause Presentation (wait for user)
- Step 7: User QA/QC Gate (keep/modify/accept)
- Step 8: Strategic Recalibration (learn from decisions)
- Step 9: Optional Summary (if requested)
- Step 10: Optional Reference Update (submit to v1.2)

**Confidence Thresholds:**
- DEALBREAKER: Any uncertainty â†’ Ask immediately
- CRITICAL (95%+): Payment, liability, IP, indemnification
- IMPORTANT (90%+): Warranties, termination, assignment
- STANDARD (85%+): Boilerplate, notices, governing law

### 3. 02_CLAUSE_PATTERN_LIBRARY_v1.1_COMPLETE.md
**Purpose:** Complete pattern library with revision language  
**Size:** 122KB  
**Structure:** 7 parts + 4 appendices  
**Key Content:**
- Part 1: Quick Reference & Navigation (pattern selection matrix)
- Part 2: Core Patterns (33 patterns - v1.0 enhanced)
- Part 3: Specialized Patterns (19 new patterns)
- Part 4: Coordination Clusters (4 systematic frameworks)
- Part 5: Negotiation Framework (success rates, talking points, fallbacks)
- Part 6: Dealbreaker Detection (walk-away triggers, mismatch detection)
- Part 7: Application Notes (by position, industry, complexity)
- Appendices: Cross-reference, methodology, version history, submission process

### 4. 03_QUICK_REFERENCE_CHECKLIST_v1.1_EPC.docx
**Purpose:** Red flags and dependency maps  
**Key Content:**
- Red flags by contract type (Upstream Owner / Downstream Supplier)
- Dependency cascade maps (Payment/Liability/Acceptance/Scope/Schedule)
- EPC position-specific focus areas
- Combined trigger detection (Combinations A-E)
- Industry-specific adjustments (Automation, Power, Infrastructure)

---

## PATTERN LIBRARY STRUCTURE (DETAILED)

### Part 1: Quick Reference & Navigation
**Purpose:** Fast pattern lookup and selection  
**Key Sections:**
- 1.1: Pattern Selection Matrix (by position Ã— contract type)
- 1.2: Key Innovations Showcase (Batch 1-3 breakthroughs)
- 1.3: Navigation Guide (how to use library)
- 1.4: Success Rate Quick Reference (by contract type)
- 1.5: Dependency Quick Map (pattern relationships)

### Part 2: Core Patterns (33 patterns)
**Numbering:** 2.1.x through 2.11.x  
**Categories:**

#### 2.1: Limitation of Liability (3 patterns)
- 2.1.1: Mutual Cap Pattern (v1.0: LOL-1)
- 2.1.2: Carve-Out Protection (v1.0: LOL-2)
- 2.1.3: Super Cap for IP (v1.0: LOL-3)

#### 2.2: Indemnification (5 patterns)
- 2.2.1: Mutual Indemnification (v1.0: IND-1)
- 2.2.2: Knowledge Qualifier (v1.0: IND-2)
- 2.2.3: Duty to Mitigate (v1.0: IND-3)
- 2.2.4: IP Indemnity Notice Period (NEW - Batch 1)
- 2.2.5: Environmental Warranty (NEW - Batch 1)

#### 2.3: Payment Terms (3 patterns)
- 2.3.1: Net 30 Standard (v1.0: PAY-1, enhanced with service variant)
- 2.3.2: Milestone Payments (v1.0: PAY-2, enhanced with integrator variant)
- 2.3.3: Dispute Rights (v1.0: PAY-3, enhanced from Batch 1)

#### 2.4: Vendor Displacement (3 patterns)
- 2.4.1: Customer Protection Period (v1.0: VD-1)
- 2.4.2: Commission on Direct Sales (v1.0: VD-2)
- 2.4.3: Introduction Documentation (v1.0: VD-3)

#### 2.5: Non-Solicitation (2 patterns)
- 2.5.1: Mutual Non-Solicit (v1.0: NS-1)
- 2.5.2: Key Employee Carve-Out (v1.0: NS-2)

#### 2.6: Assignment (3 patterns)
- 2.6.1: Competitive Exclusion (v1.0: ASN-1)
- 2.6.2: Change of Control (v1.0: ASN-2)
- 2.6.3: Assignment to End User (NEW - Batch 1)

#### 2.7: Exclusivity (2 patterns)
- 2.7.1: Limited Exclusivity (v1.0: EXC-1)
- 2.7.2: Performance-Based (v1.0: EXC-2)

#### 2.8: Termination (3 patterns)
- 2.8.1: Mutual Termination (v1.0: TRM-1)
- 2.8.2: Cure Period (v1.0: TRM-2)
- 2.8.3: Wind-Down Protection (v1.0: TRM-3)

#### 2.9: Operational Burden (3 patterns)
- 2.9.1: Defined Response Times (v1.0: OB-1)
- 2.9.2: Reasonableness Standard (v1.0: OB-2)
- 2.9.3: Escalation Path (v1.0: OB-3)

#### 2.10: Back-to-Back Protection (4 patterns)
- 2.10.1: Flow-Down Protection (v1.0: B2B-1)
- 2.10.2: Gap Coverage (v1.0: B2B-2)
- 2.10.3: Back-to-Back Liability (NEW - Batch 1, enhanced)
- 2.10.4: Prime Contract Flowdown (NEW - Batch 1)

#### 2.11: Standard Definitions (2 patterns)
- 2.11.1: Gross Negligence (v1.0: NSD-1)
- 2.11.2: Business Day (v1.0: NSD-2)

### Part 3: Specialized Patterns (19 patterns)
**Numbering:** 3.1.x through 3.5.x  
**All NEW in v1.1**

#### 3.1: Systems Integrator (6 patterns) - FROM BATCH 1
- 3.1.1: Customer Protection Complete Section
- 3.1.2: Warranty Coordination (prevent vendor displacement)
- 3.1.3: Final Acceptance Alignment (to end user/Owner)
- 3.1.4: Software License Transfer Rights
- 3.1.5: Security Interest Time Limits
- 3.1.6: Markup Limitations on Pass-Throughs

#### 3.2: Service Provider (5 patterns) - FROM BATCH 2
- 3.2.1: SOW Change Control
- 3.2.2: Project Delays Attribution
- 3.2.3: Audit Rights Limitations
- 3.2.4: Professional Liability Insurance
- 3.2.5: Time & Materials Markup

#### 3.3: NDA & Structure (4 patterns) - FROM BATCH 3
- 3.3.1: Business Model Mismatch Detection (pre-review framework)
- 3.3.2: NDA Mutual Scope
- 3.3.3: NDA Return/Destruction
- 3.3.4: Scope Interface Definition

#### 3.4: Mutual Agreement Balance (2 patterns) - FROM BATCH 3
- 3.4.1: Reciprocity Testing Framework
- 3.4.2: Hidden One-Way Provisions

#### 3.5: Execution Quality (2 patterns) - FROM BATCH 3
- 3.5.1: Deliverable Quality Framework
- 3.5.2: Section Number Verification Protocol

### Part 4: Coordination Clusters (4 clusters)
**Purpose:** Systematic approach for related patterns that must work together

#### 4.1: Customer Protection System (6 patterns coordinated)
- Prevents Owner/Customer from establishing direct relationships with your Suppliers
- Protects revenue stream and margin
- **Coordinated Patterns:** 2.4.1, 2.4.2, 2.4.3, 3.1.1, 3.1.2, 2.5.1

#### 4.2: Payment & Acceptance Flow (8 patterns coordinated)
- Aligns cash flow IN (from Owner) with cash flow OUT (to Suppliers)
- Minimizes financing burden (gap < 30 days ideal)
- **Coordinated Patterns:** 2.3.2, 3.1.3, 3.1.5, 2.3.3, 2.9.1, 3.3.4, 2.3.1, 3.2.5

#### 4.3: Liability Flow-Through (5 patterns coordinated)
- Matches liability TO Owner with liability FROM Supplier
- Ensures gaps are insurable or priced into margin
- **Coordinated Patterns:** 2.10.3, 2.1.1, 2.2.4, 2.10.4, 3.1.2

#### 4.4: Audit & Documentation Control (4 patterns coordinated)
- Limits audit burden and protects proprietary methods
- **Coordinated Patterns:** 3.2.3, 2.4.3, 3.3.3, 3.5.1

#### 4.5: Cross-Batch Master Matrix
- Dependency map across all 52 patterns
- Shows which patterns must be considered together

### Part 5: Negotiation Framework
**Key Sections:**
- 5.1: Success Rate Calibration Tables (by contract type + leverage)
- 5.2: Talking Points Library (negotiation scripts for each pattern)
- 5.3: Fallback Position Decision Trees (4-tier framework)
- 5.4: Industry & Context Adjustments

**4-Tier Fallback Framework (applies to ALL 52 patterns):**
1. **Optimal:** Best protection, highest success for your position
2. **Strong:** Good protection, commercially reasonable
3. **Acceptable:** Minimum acceptable, identified trade-offs
4. **Walk-Away:** Triggers that make deal unviable

### Part 6: Dealbreaker Detection
**Key Sections:**
- 6.1: Three-Tier Walk-Away Framework (Absolute / High Risk / Context-Dependent)
- 6.2: Business Model Mismatch Detection (Pattern 3.3.1 framework)
- 6.3: Combined Pattern Triggers (dealbreaker combinations)
- 6.4: Industry-Specific Red Flags

**Combined Trigger Patterns (STOP immediately if detected):**
- **Combination A:** Unlimited liability + short notice + no insurance requirement
- **Combination B:** Payment after acceptance + undefined acceptance + no dispute resolution
- **Combination C:** Broad warranty + short cure + liquidated damages uncapped
- **Combination D:** IP ownership transfer + no license-back + indemnity unlimited
- **Combination E:** Cost-plus with audit + no markup limit + flow-through restrictions

### Part 7: Application Notes
**Key Sections:**
- 7.1: By Position (Customer, Vendor, Reseller, Integrator, Service Provider)
- 7.2: By Industry (Tech, Manufacturing, Services, Distribution, Construction)
- 7.3: By Complexity (Simple, Standard, Complex contracts)
- 7.4: Quality Control Framework (deliverable accuracy standards)

### Appendices (4)
- **Appendix A:** Pattern Numbering Cross-Reference (v1.0 â†’ v1.1 migration guide)
- **Appendix B:** Success Rate Methodology & Sources (how rates calculated)
- **Appendix C:** Version History & Update Log (Batch 1-3 integration details)
- **Appendix D:** Pattern Submission Process for v1.2 (crowdsourcing framework)

---

## VERSION COMPARISON MATRIX

### Pattern Count Evolution

| Category | v1.0 | v1.1 | Change |
|----------|------|------|--------|
| Core Patterns | 33 | 33 | Enhanced, renumbered |
| Systems Integrator | 0 | 6 | NEW (Part 3.1) |
| Service Provider | 0 | 5 | NEW (Part 3.2) |
| NDA & Structure | 0 | 4 | NEW (Part 3.3) |
| Mutual Agreement | 0 | 2 | NEW (Part 3.4) |
| Execution Quality | 0 | 2 | NEW (Part 3.5) |
| Coordination Clusters | 0 | 4 | NEW (Part 4) |
| **TOTAL** | **33** | **52 + 4** | **+19 patterns, +4 clusters** |

### Numbering System Change

| v1.0 Format | Example | v1.1 Format | Example |
|-------------|---------|-------------|---------|
| Prefix-based | LOL-1, IND-2, PAY-3 | Hierarchical | 2.1.1, 2.2.2, 2.3.3 |
| Category + Number | IND-1 (Indemnification #1) | Part.Category.Pattern | 2.2.1 (Part 2, Category 2, Pattern 1) |

### Methodology Enhancements

| Feature | v1.0 | v1.1 |
|---------|------|------|
| **Fallback Framework** | Basic or none | 4-tier for ALL patterns |
| **Walk-Away Triggers** | Implicit | Explicit for every pattern |
| **Talking Points** | Limited | Comprehensive (all 52) |
| **Success Rates** | Basic estimates | Calibrated (type + leverage) |
| **Dependencies** | Mentioned | Mapped (pattern + matrix) |
| **Mismatch Detection** | None | Pattern 3.3.1 + Part 6.2 |
| **Combined Triggers** | None | Part 6.3 (5 combinations) |
| **Coordination Clusters** | None | Part 4 (4 frameworks) |
| **EPC Optimization** | None | Complete (v1.1) |

### v1.0 â†’ v1.1 Cross-Reference (Complete)

| v1.0 # | v1.0 Name | v1.1 # | Status |
|--------|-----------|--------|--------|
| LOL-1 | Mutual Cap Pattern | 2.1.1 | Enhanced with variants |
| LOL-2 | Carve-Out Protection | 2.1.2 | Unchanged |
| LOL-3 | Super Cap for IP | 2.1.3 | Unchanged |
| IND-1 | Mutual Indemnification | 2.2.1 | Unchanged |
| IND-2 | Knowledge Qualifier | 2.2.2 | Unchanged |
| IND-3 | Duty to Mitigate | 2.2.3 | Unchanged |
| â€” | IP Indemnity Notice | 2.2.4 | NEW (Batch 1) |
| â€” | Environmental Warranty | 2.2.5 | NEW (Batch 1) |
| PAY-1 | Net 30 Standard | 2.3.1 | Enhanced (service variant) |
| PAY-2 | Milestone Payments | 2.3.2 | Enhanced (integrator variant) |
| PAY-3 | Dispute Rights | 2.3.3 | Enhanced (Batch 1) |
| VD-1 | Customer Protection Period | 2.4.1 | Unchanged |
| VD-2 | Commission on Direct Sales | 2.4.2 | Unchanged |
| VD-3 | Introduction Documentation | 2.4.3 | Unchanged |
| NS-1 | Mutual Non-Solicit | 2.5.1 | Unchanged |
| NS-2 | Key Employee Carve-Out | 2.5.2 | Unchanged |
| ASN-1 | Competitive Exclusion | 2.6.1 | Unchanged |
| ASN-2 | Change of Control | 2.6.2 | Unchanged |
| â€” | Assignment to End User | 2.6.3 | NEW (Batch 1) |
| EXC-1 | Limited Exclusivity | 2.7.1 | Unchanged |
| EXC-2 | Performance-Based | 2.7.2 | Unchanged |
| TRM-1 | Mutual Termination | 2.8.1 | Unchanged |
| TRM-2 | Cure Period | 2.8.2 | Unchanged |
| TRM-3 | Wind-Down Protection | 2.8.3 | Unchanged |
| OB-1 | Defined Response Times | 2.9.1 | Unchanged |
| OB-2 | Reasonableness Standard | 2.9.2 | Unchanged |
| OB-3 | Escalation Path | 2.9.3 | Unchanged |
| B2B-1 | Flow-Down Protection | 2.10.1 | Unchanged |
| B2B-2 | Gap Coverage | 2.10.2 | Unchanged |
| â€” | Back-to-Back Liability | 2.10.3 | NEW (Batch 1, enhanced) |
| â€” | Prime Contract Flowdown | 2.10.4 | NEW (Batch 1) |
| NSD-1 | Gross Negligence | 2.11.1 | Unchanged |
| NSD-2 | Business Day | 2.11.2 | Unchanged |

**All Part 3 patterns (3.1.1 through 3.5.2) are NEW in v1.1**

---

## EPC SYSTEM INTEGRATOR OPTIMIZATION

### Business Context
**Role:** Prime Contractor managing multi-party flowdowns  
**Structure:** Owner/Customer â†’ YOU â†’ Suppliers/Subcontractors  
**Objective:** Deliver projects on Quality, Schedule, and Margin targets

### The Iron Triangle (Every Decision Optimizes)
1. **Quality:** Can you deliver to Owner specs with Supplier capabilities?
2. **Schedule:** Are approval/payment timings aligned to prevent delays?
3. **Margin:** Are costs controlled, scope defined, markups preserved?

### Critical Success Factors

#### 1. Multi-Party Flowdown Strategy
**Priority Alignments:**
1. Payment Terms: Owner payment IN = Supplier payment OUT (minimize gap)
2. Acceptance Criteria: Owner acceptance = Your acceptance = Supplier acceptance
3. Liability Caps: Your cap to Owner â‰¥ Supplier cap to you (no gap)
4. Warranty Terms: Supplier warranty covers Owner warranty requirements
5. Change Orders: Owner change process timing allows Supplier change process
6. Scope Definition: Clear interfaces prevent scope creep

#### 2. Cash Flow Management (No Project Financing)
**Goal:** Minimize financing burden  
**Ideal:** Payment gap < 30 days  
**Warning:** Gap > 45 days impacts margin  
**Critical:** Gap > 60 days = potential cash flow crisis

**Mitigation Strategies:**
1. Tie Supplier payment to Owner acceptance (Pattern 2.3.2 integrator variant)
2. Negotiate milestone payments from Owner (30/40/30 structure)
3. Negotiate payment terms from Supplier (Net 60 vs Net 30)
4. Price financing cost into margin (calculate interest, add to bid)
5. Walk away if gap exceeds margin on project

#### 3. Supplier Relationship Management
**Prevent Displacement (Critical for Margin):**
- Pattern 3.1.1: Customer protection complete section (24-month non-solicit)
- Pattern 3.1.2: All warranty claims flow through you
- Pattern 2.4.3: Document customer introductions

**Maintain Quality (Critical for Deliverables):**
- Pattern 3.3.4: Scope interface definition
- Acceptance criteria tied to Owner requirements
- Warranty terms adequate to cover Owner obligations

**Protect Schedule (Critical for Completion):**
- Pattern 2.9.1: 5-10 day response times with deemed approval
- Pattern 2.8.2: 30-day cure period
- Change order process aligned with Owner process

**Preserve Margin (Critical for Profit):**
- Pattern 3.1.6: Limit markups on pass-throughs
- Scope clearly defined (prevent scope creep)
- Payment timing aligned (minimize financing)

### Contract Type Priorities

#### UPSTREAM (Owner/Customer Contracts)
**Check FIRST:**
1. **Payment & Acceptance** (Part 4.2 cluster)
   - Pattern 2.3.2: Milestone payments tied to acceptance
   - Pattern 3.1.3: Final acceptance aligned to Owner
   - Pattern 3.1.5: Security interest time limits

2. **Liability Flow-Through** (Part 4.3 cluster)
   - Pattern 2.10.3: Back-to-back liability alignment
   - Pattern 2.2.4: IP indemnity notice (15 days)
   - Pattern 2.1.1: Liability cap alignment

3. **Customer Protection** (Part 4.1 cluster)
   - Pattern 3.1.1: Customer protection complete section
   - Pattern 3.1.2: Warranty coordination
   - Pattern 3.1.4: Software license transfer

#### DOWNSTREAM (Supplier/Subcontractor Agreements)
**Check FIRST:**
1. **Flowdown Provisions**
   - Pattern 2.10.4: Prime contract flowdown clause
   - Pattern 3.1.2: Warranty claim flow-through
   - Pattern 3.3.4: Scope interface definition

2. **Payment Timing**
   - Pattern 2.3.2 (integrator variant): Tie to upstream acceptance
   - Align payment OUT to payment IN (minimize gap)

3. **Relationship Protection**
   - Pattern 3.1.1: Non-solicitation (24 months)
   - Pattern 3.1.6: Markup limitations on pass-throughs

---

## WORKFLOW PROTOCOL

### Auto-Start (On .docx Upload)
**IMMEDIATELY ask these 3 questions:**

**Question 1: Contract Type**
- [ ] UPSTREAM (Owner/Customer) - You're bidding/accepting work
- [ ] DOWNSTREAM (Supplier/Sub) - You're hiring for project
- [ ] TEAMING/PARTNER - Joint venture, alliance, consortium
- [ ] OTHER - NDA, service agreement, equipment purchase

**Question 2: Position & Leverage**
- **Position:** EPC Prime, Subcontractor, Equipment Supplier, Design-Build, etc.
- **Leverage:** 
  - Strong (they need you more)
  - Balanced (mutual benefit)
  - Weak (you need them more)

**Question 3: Context**
- Project type (industrial automation, power, infrastructure, etc.)
- Key concerns (margin squeeze, schedule risk, technical complexity, etc.)
- Prior relationship history (if relevant)

### Business Model Mismatch Detection (Pattern 3.3.1)
**Run BEFORE detailed review:**
- Does contract structure match business objective?
- Are required structural elements present?
- Any fundamental rights asymmetries?
- **If mismatch detected:** STOP and alert user before detailed review

### Clause-by-Clause Review Process
**Steps for each clause:**
1. Extract exact text (10-15 word minimum quote with section number)
2. Assess against Pattern Library (check if pattern applies)
3. Check dependencies (does this impact other sections?)
4. Determine revision need (based on position, leverage, EPC context)
5. Format revision properly (see formatting standard below)
6. Present ONE clause at a time
7. **WAIT for user QA/QC** before proceeding

### Formatting Standard
```
SECTION X.X - [TITLE]

CURRENT TEXT:
"[Exact quote from contract, 10-15 words minimum]"

ISSUE:
[Business impact in commercial terms - effect on quality/schedule/margin]

RECOMMENDED REVISION:
~~strikethrough deleted words~~ `inline code for added words`

PATTERN REFERENCE: [Pattern number from library]
SUCCESS PROBABILITY: [X]% ([leverage level])
DEPENDENCIES: [List affected sections]

RATIONALE:
[Why this change matters for EPC business model]
```

### User QA/QC Integration
**After each clause, user responds with:**

**Option 1: "Keep original" (with reasoning)**
- Your action: Learn from reasoning, recalibrate approach
- Extract lesson: What did I misunderstand about business context?
- Adjust remaining clauses: Apply learning

**Option 2: "Modify your suggestion" (with changes)**
- Your action: Implement user's modification exactly
- Extract lesson: What pattern variation is preferred?
- Document for future: Calibration datapoint

**Option 3: "Accept completely"**
- Your action: Move to next clause
- Confidence boost: Pattern works in this context

**CRITICAL:** Never proceed to next clause until user responds

---

## QUALITY CONTROL FRAMEWORK

### Pre-Presentation Checklist (Before ANY Revision)

#### Accuracy Checks
- [ ] Section number verified against actual contract (searched, not guessed)
- [ ] Exact quote from contract (no paraphrasing, 10-15 word minimum)
- [ ] Context sufficient to identify location (not ambiguous)
- [ ] All cross-references checked (Section X.X actually exists)

#### Formatting Checks
- [ ] ~~Strikethrough~~ for deletions only (word-level, not sentence)
- [ ] `Inline code` for additions only (word-level precision)
- [ ] No mixed formatting (don't combine styles)
- [ ] Clean presentation (ready to copy/paste into contract)

#### Business Checks
- [ ] Commercial impact clear (quality/schedule/margin effect)
- [ ] Pattern reference cited from library
- [ ] Success probability provided (calibrated to context)
- [ ] Dependencies identified (what else this affects)
- [ ] Flowdown implications noted (if applicable)

#### EPC-Specific Checks
- [ ] Upstream/downstream alignment considered
- [ ] Cash flow timing analyzed (payment gap calculated)
- [ ] Liability gap checked (can you insure/flowdown?)
- [ ] Schedule impact assessed (approval bottlenecks?)
- [ ] Margin protection verified (markup preserved?)

### Confidence Threshold Application

**DEALBREAKER (Ask immediately):**
- Any uncertainty on critical terms
- Combined trigger patterns detected (Part 6.3)
- Business model mismatch (Pattern 3.3.1)

**CRITICAL (95%+ required):**
- Payment terms, liability caps, IP ownership, indemnification
- Patterns: 2.1.x, 2.2.x, 2.3.x series

**IMPORTANT (90%+ required):**
- Warranties, termination rights, assignment restrictions
- Patterns: 2.4.x, 2.5.x, 2.6.x, 2.7.x, 2.8.x series

**STANDARD (85%+ required):**
- Boilerplate, notices, governing law
- Patterns: 2.9.x, 2.11.x series

---

## EMERGENCY PROCEDURES

### If You Cannot Find Section Referenced
1. **STOP immediately**
2. Tell user: "I cannot locate Section X.X in the contract. Can you help me find it or confirm the section number?"
3. **Do NOT guess or proceed**

### If Unsure About Business Context
1. **STOP immediately**
2. Ask: "To assess this properly, I need to understand [specific context]. Can you clarify?"
3. **Wait for response** before proceeding

### If DEALBREAKER Combination Detected
1. **STOP immediately**
2. Alert: "DEALBREAKER DETECTED: [Combination A/B/C/D/E] - [explain commercial impact]"
3. Recommend: "This creates [uninsurable risk / cash flow death / margin destruction]. Suggest [walk away / major restructure / escalate to executive]"
4. **Do NOT continue** review without user decision

### If Business Model Mismatch Discovered (Pattern 3.3.1)
1. **STOP detailed review**
2. Alert: "Business model mismatch detected. This appears to be [contract type] but your objective requires [different type]."
3. Recommend: "Request appropriate contract type before investing time in detailed review."

---

## CONTEXT WINDOW MANAGEMENT

### At 80% Capacity
1. Alert user: "Context at 80% - preparing checkpoint after current clause"
2. Complete current clause QA/QC
3. Create minimal checkpoint (see format below)
4. Start new chat with checkpoint info
5. User can provide additional context during recovery if needed

### Checkpoint Format
```
CHECKPOINT
Position: [EPC Prime / Sub / etc.]
Contract Type: [Upstream Owner / Downstream Supplier / etc.]
Leverage: [Strong/Balanced/Weak]
Context: [One-line project summary]
At: Section [X.X] - [Title]
Key Decisions: 
- [Section X.X]: [Keep original / Modified / Accepted] - [Reason if modified]
- [Section Y.Y]: [Decision] - [Reason]
Resume: Next section is [X.X] - [Title]
```

---

## RAG RETRIEVAL OPTIMIZATION

### Primary Search Terms for Pattern Lookup

**By Clause Type:**
- Liability â†’ Patterns 2.1.x
- Indemnification â†’ Patterns 2.2.x
- Payment â†’ Patterns 2.3.x
- Customer/Vendor Protection â†’ Patterns 2.4.x, 3.1.1, 3.1.2
- Non-Solicitation â†’ Patterns 2.5.x
- Assignment â†’ Patterns 2.6.x
- Exclusivity â†’ Patterns 2.7.x
- Termination â†’ Patterns 2.8.x
- Approval/Response Times â†’ Patterns 2.9.x
- Flow-Down/Back-to-Back â†’ Patterns 2.10.x
- Definitions â†’ Patterns 2.11.x

**By Contract Type:**
- Systems Integrator â†’ Part 3.1 (patterns 3.1.1-3.1.6)
- Service Provider â†’ Part 3.2 (patterns 3.2.1-3.2.5)
- NDA â†’ Part 3.3 (patterns 3.3.2-3.3.3)
- Mutual Agreements â†’ Part 3.4 (patterns 3.4.1-3.4.2)

**By Business Objective:**
- Prevent customer displacement â†’ Part 4.1 cluster
- Align cash flow â†’ Part 4.2 cluster
- Match liability exposure â†’ Part 4.3 cluster
- Control audit burden â†’ Part 4.4 cluster

**By Risk Level:**
- Dealbreakers â†’ Part 6 (all sections)
- Critical issues â†’ Patterns with 95%+ threshold
- Business model mismatch â†’ Pattern 3.3.1 + Part 6.2

### Key Retrieval Patterns

**Question Format: "How do I handle [clause type] in [contract type] contract?"**
â†’ Search: Part 2 (clause type) + Part 3 (contract type) + Part 4 (coordination)

**Question Format: "What are dealbreakers for [situation]?"**
â†’ Search: Part 6.1 (walk-away framework) + Part 6.3 (combined triggers)

**Question Format: "What's my negotiation strategy for [pattern]?"**
â†’ Search: Pattern number + Part 5.1 (success rates) + Part 5.2 (talking points)

**Question Format: "How do I detect business model mismatch?"**
â†’ Search: Pattern 3.3.1 + Part 6.2

**Question Format: "What patterns coordinate with [pattern X]?"**
â†’ Search: Pattern X dependencies + Part 4 (coordination clusters) + Part 4.5 (master matrix)

---

## SUCCESS METRICS

### System Performance Targets
- **98%+ accuracy** on section references and quotes
- **Zero formatting errors** in revision presentation
- **Every DEALBREAKER** caught and flagged
- **User confidence** through clear reasoning
- **Clean revisions** ready to paste into contracts

### EPC Business Targets (User Success)
1. **Quality:** Deliverables meet specs, warranties adequate
2. **Schedule:** No bottlenecks, timing aligned
3. **Margin:** Costs controlled, scope defined, financing minimized
4. **Risk Management:** Exposure quantified, gaps closed or priced
5. **Relationships:** Suppliers protected from displacement, Owners satisfied

---

## VERSION IDENTIFICATION QUICK CHECK

### How to Tell Which Version You Have

**Check 1: Pattern Numbering**
- v1.0: `LOL-1`, `IND-2`, `PAY-3` format
- v1.1: `2.1.1`, `2.2.2`, `2.3.3` format

**Check 2: File Structure**
- v1.0: No Part 3 (specialized patterns)
- v1.1: Has Part 3 with Systems Integrator, Service Provider sections

**Check 3: Fallback Tiers**
- v1.0: Not systematically applied
- v1.1: Every pattern has 4 tiers (Optimal â†’ Strong â†’ Acceptable â†’ Walk-Away)

**Check 4: File Size**
- v1.0: ~50KB (estimated)
- v1.1: 122KB

**Check 5: Version Statement**
- Look for explicit version number at top/bottom of file

---

## PATTERN LIBRARY v1.2 ROADMAP

### Pattern Submission Process (Appendix D)
**Requirements for Submission:**
- Minimum 2 real-world contract observations
- Documented outcomes (accepted/rejected/modified)
- Complete validation data (leverage, industry, context)
- 4-tier fallback framework
- Talking points for negotiation

**Submission Template Elements:**
1. Pattern name and category
2. Problem statement (what risk/gap it addresses)
3. Exact revision language (word-for-word)
4. Base success rate (with methodology)
5. Calibration data (by contract type + leverage)
6. 4-tier fallback positions
7. Talking points (3-5 negotiation phrases)
8. Dependencies (which patterns it coordinates with)
9. Walk-away triggers (when to decline)
10. Validation observations (minimum 2)

### v1.2 Release Triggers
- 10+ new validated patterns submitted
- Significant methodology enhancement identified
- Critical coverage gap discovered
- Annual review cycle (minimum)

---

## FINAL REMINDERS FOR AI ASSISTANT

### Core Commitments
1. **User is ultimate QA/QC** - Rely on their guidance, never guess
2. **One clause at a time** - In original contract order, wait for response
3. **Ask when uncertain** - Never guess section numbers or business context
4. **Format perfectly** - Strikethrough/inline code matters for usability
5. **Business value first** - Optimize quality, schedule, margin (not just legal perfection)
6. **EPC context always** - Consider upstream/downstream flowdown implications
7. **Accuracy over speed** - Credibility depends on precision (98%+ section verification)

### What Success Looks Like
- Clean revisions ready to paste into contracts
- User confident in commercial rationale
- All dealbreakers caught before they become problems
- Flowdown implications clearly explained
- Margin protection verified on every clause

---

**END OF RAG REFERENCE GUIDE**

**Document Purpose:** Complete system reference for AI retrieval and contract review operations  
**Last Updated:** October 19, 2025  
**Version:** 1.1  
**Status:** âœ… Production Ready

**This document should be uploaded to project knowledge for optimal RAG retrieval.**
